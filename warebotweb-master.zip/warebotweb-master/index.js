
var firebaseConfig = {
    apiKey: "AIzaSyALIxWc98nMBPC5opE4cG_o-4zF3epKwDQ",
    authDomain: "warebot-6957c.firebaseapp.com",
    databaseURL: "https://warebot-6957c-default-rtdb.firebaseio.com",
    projectId: "warebot-6957c",
    storageBucket: "warebot-6957c.appspot.com",
    messagingSenderId: "772347476312",
    appId: "1:772347476312:web:dd68b3449643fc8c16cd2d",
    measurementId: "G-HNR0VKT0PD"
};


var chartobj = null;

var datasetdata = {
    "labels": [],
    "dataset": [{
        label: 'Temperature',
        data: [],
        borderWidth: 1
    }, {
        label: 'Humidity',
        data: [],
        borderWidth: 1
    }, {
        label: 'ppm',
        data: [],
        borderWidth: 1
    }]
}
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Get a reference to the Firebase Realtime Database
var database = firebase.database();

var messagesRef = database.ref("Device/08:D1:F9:98:E0:B2/graph");

// Function to generate a random number between a min and max value
function getRandomValue(min, max) {
    return Math.random() * (max - min) + min;
}

// Function to generate and upload dummy data for the past two years
function generateAndUploadDummyData() {
    const now = new Date(); // Current date and time
    const twoYearsAgo = new Date(now);
    twoYearsAgo.setFullYear(now.getFullYear()-0.6);

    let currentDate = new Date(twoYearsAgo); // Initialize with a date 2 years ago


    while (currentDate <= now) {
        
        // Format the time as HH:MM:SS
        const formattedTime = currentDate.toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
        });

        // Format the date as MM/DD/YYYY
        const formattedDate = currentDate.toLocaleDateString('en-US', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
        });

        // Combine date and time
        const formattedDateTime = `${formattedDate}_${formattedTime}`;

        console.log('Formatted Date and Time:', formattedDateTime);

        const data = {
            date: formattedDateTime, // Date and time as ISO string
            co2: getRandomValue(300, 2000), // Replace with your desired range
            temp: getRandomValue(10, 30), // Replace with your desired range
            humd: getRandomValue(30, 70), // Replace with your desired range
        };

        database.ref("Device/08:D1:F9:98:E0:B2/graph/"+formattedDateTime.replaceAll("/","-")).set(data, () => {
            console.log('Dummy data uploaded successfully.');

        }); // Upload data to Firebase

        // Increment the current date by one day
        currentDate.setDate(currentDate.getDate() + 1);
    }

}

generateAndUploadDummyData();

messagesRef.on("value", function (snapshot) {
    // This function will be called whenever data changes

    if (chartobj) {
        var messages = snapshot.val();
        // Handle the updated data
        console.log("New data received:", snapshot, messages, Object.keys(messages)[1], new Date(Object.keys(messages)[1]));
        datasetdata.labels = []
        datasetdata.dataset[0].data = []
        datasetdata.dataset[1].data = []
        datasetdata.dataset[2].data = []
        Object.keys(messages).map((e, i) => {
            var date = new Date(e * 1000).toLocaleString();
            datasetdata.labels.push(date)
            datasetdata.dataset[0].data.push(messages[e].temp)
            datasetdata.dataset[1].data.push(messages[e].hmd)
            datasetdata.dataset[2].data.push(messages[e].ppm)
        })

        chartobj.data.dataset = datasetdata.dataset;
        chartobj.data.labels = datasetdata.labels;
        chartobj.update();
    }


});

messagesRef.once("value", function (snapshot) {
    // This function will be called whenever data changes
    var messages = snapshot.val();
    // Handle the updated data
    console.log("New data received:", messages, Object.keys(messages)[1], new Date(Object.keys(messages)[1]));
    Object.keys(messages).map((e, i) => {
        var date = new Date(e * 1000).toLocaleString();
        datasetdata.labels.push(date)
        datasetdata.dataset[0].data.push(messages[e].temp)
        datasetdata.dataset[1].data.push(messages[e].hmd)
        datasetdata.dataset[2].data.push(messages[e].ppm)
    })

    const ctx = document.getElementById('myChart');

    chartobj = new Chart(ctx, {
        type: 'line',
        responsive: true,
        data: {
            labels: datasetdata.labels,
            datasets: datasetdata.dataset
        },
        options: {

            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

});




var newDataRef = database.ref("am2305/data/" + new Date().getTime())
// Write data with a timestamp

newDataRef.set({ "hmd": Math.floor(Math.random() * 10) + 1, "temp": Math.floor(Math.random() * 120) + 1, "ppm": Math.floor(Math.random() * 50) + 1 }, function (error) {
    if (error) {
        console.log("Data could not be saved." + error);

    } else {
        console.log("Data saved successfully with timestamp: " + new Date().getTime());
        //   window.location.reload();
    }
});

