import {
  AppBar,
  Container,
  Toolbar,
  Typography,
  Box,
  IconButton,
  MenuItem,
  Button,
  Avatar,
  Tooltip,
} from "@mui/material";
import React, { Component } from "react";
import AdbIcon from "@mui/icons-material/Adb";
import MenuIcon from "@mui/icons-material/Menu";
import Menu from "@mui/material/Menu";
import { Outlet } from "react-router-dom";
import { getCookie, storeCookie } from "../controller/cookie.controller";
import Cookies from "js-cookie";
import logo from "../assets/logobot.gif";
export default class Navbar extends Component {
  state: Readonly<{
    pages: any;
    settings: any;
    anchorElUser: any;
    anchorElNav: any;
    userinfo: any;
  }>;

  constructor(props: any) {
    super(props);
    this.state = {
      pages: ["Home"],
      settings: ["Logout"],
      anchorElUser: null,
      anchorElNav: null,
      userinfo: null,
    };
  }

  handleOpenNavMenu = (event: any) => {
    this.setState({ anchorElNav: event.currentTarget });
  };
  handleOpenUserMenu = (event: any) => {
    this.setState({ anchorElUser: event.currentTarget });
  };

  handleCloseNavMenu = (e: any) => {
    var item = e.target.innerText;
    console.log(item);

    if (item.toLowerCase() == "home") {
      window.location.replace("/");
    }
    this.setState({ anchorElNav: null });
  };

  handleCloseUserMenu = (e: any) => {
    console.log(e.target.innerHTML);
    var item = e.target.innerHTML;

    if ("Logout" == item) {
      Cookies.remove("__tkn__");
      window.location.replace("/login");
    }

    this.setState({ anchorElUser: null });
  };

  componentDidMount(): void {
    var profile: any = getCookie("profile");
    if (profile) {
      console.log(profile);
      this.setState({ userinfo: JSON.parse(profile) });
    } else {
      window.location.replace("/login");
    }
  }

  render() {
    const { pages, settings, anchorElNav, anchorElUser, userinfo } = this.state;
    return (
      <div>
        <AppBar position="static">
          <Container maxWidth="xl">
            <Toolbar disableGutters>
              <img
                src={logo}
                alt=""
                style={{ width: "150px", height: "55px" }}
              />

              <Box sx={{ flexGrow: 1, display: { xs: "flex", md: "none" } }}>
                <IconButton
                  size="large"
                  aria-label="account of current user"
                  aria-controls="menu-appbar"
                  aria-haspopup="true"
                  onClick={this.handleOpenNavMenu}
                  color="inherit"
                >
                  <MenuIcon />
                </IconButton>
                <Menu
                  id="menu-appbar"
                  anchorEl={anchorElNav}
                  anchorOrigin={{
                    vertical: "bottom",
                    horizontal: "left",
                  }}
                  keepMounted
                  transformOrigin={{
                    vertical: "top",
                    horizontal: "left",
                  }}
                  open={Boolean(anchorElNav)}
                  onClose={this.handleCloseNavMenu}
                  sx={{
                    display: { xs: "block", md: "none" },
                  }}
                >
                  {pages.map((page: any) => (
                    <MenuItem
                      key={page}
                      id={page}
                      onClick={this.handleCloseNavMenu}
                    >
                      <Typography textAlign="center">{page}</Typography>
                    </MenuItem>
                  ))}
                </Menu>
              </Box>
              <Typography
                variant="h5"
                noWrap
                component="a"
                href="/"
                sx={{
                  mr: 2,
                  display: { xs: "flex", md: "none" },
                  flexGrow: 1,
                  fontFamily: "monospace",
                  fontWeight: 700,
                  letterSpacing: ".3rem",
                  color: "inherit",
                  textDecoration: "none",
                }}
              ></Typography>
              <Box sx={{ flexGrow: 1, display: { xs: "none", md: "flex" } }}>
                {pages.map((page: any) => (
                  <Button
                    key={page}
                    onClick={this.handleCloseNavMenu}
                    sx={{ my: 2, color: "white", display: "block" }}
                  >
                    {page}
                  </Button>
                ))}
              </Box>

              <Box sx={{ flexGrow: 0 }}>
                <Tooltip title="Open settings">
                  <IconButton onClick={this.handleOpenUserMenu} sx={{ p: 0 }}>
                    <Avatar
                      alt="Remy Sharp"
                      src={
                        userinfo
                          ? userinfo.profile
                          : "/static/images/avatar/2.jpg"
                      }
                    />
                  </IconButton>
                </Tooltip>
                <Menu
                  sx={{ mt: "45px" }}
                  id="menu-appbar"
                  anchorEl={anchorElUser}
                  anchorOrigin={{
                    vertical: "top",
                    horizontal: "right",
                  }}
                  keepMounted
                  transformOrigin={{
                    vertical: "top",
                    horizontal: "right",
                  }}
                  open={Boolean(anchorElUser)}
                  onClose={this.handleCloseUserMenu}
                >
                  {settings.map((setting: any) => (
                    <MenuItem key={setting} onClick={this.handleCloseUserMenu}>
                      <Typography textAlign="center">{setting}</Typography>
                    </MenuItem>
                  ))}
                </Menu>
              </Box>
            </Toolbar>
          </Container>
        </AppBar>

        <Outlet />
      </div>
    );
  }
}
