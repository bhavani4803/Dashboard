import React, { Component } from "react";
import Login from "./routes/Login/Login";
import Notfound from "./routes/not Found/notFound";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "./routes/Home/home";
import Device from "./routes/devices/device";
import Navbar from "./navbar/navbar";
import Admin from "./routes/admin/admin";
import Dealers from "./Dealers/Dealers";
import Auth from "./authentication/Auth/Auth";
import { withParams } from "./authentication/params";
import Adminusers from "./AdminUsers/Adminusers";
import User from "./AdminUsers/User";
import Profile from "./routes/Profile/Profile";


var AuthWithParams = withParams(Auth);
export default class route extends Component {
  render() {
    return (
      <Routes>
        <Route path="/" element={<AuthWithParams />}>
          <Route element={<Home />} index></Route>
          <Route path=":mac" element={<Device />}></Route>
          <Route path="admin" element={<Admin />}></Route>
          <Route path="viewers" element={<Dealers />}></Route>
          <Route path="users" element={<Adminusers />}></Route>
          <Route path="profile" element={<Profile />}></Route>
          <Route path="users/:useruid" element={<User />}></Route>
        </Route>
        <Route path="login" element={<Login />}></Route>
        <Route path="*" element={<Notfound />}></Route>
      </Routes>
    );
  }
}
