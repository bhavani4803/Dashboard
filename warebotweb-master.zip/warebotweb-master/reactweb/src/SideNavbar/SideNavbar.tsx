import { Menu, Button } from "antd";
import { NavLink, useLocation } from "react-router-dom";
import logo from "../assets/logobot.gif";
import React, { Component } from "react";
import { getCookie } from "../controller/cookie.controller";

interface SideNavBarProps {
  onItemClick: (selectedItem: string) => void;
}

interface SideNavBarState {
  isOpen: boolean;
  selecteditem: string;
  profile: any;
}

export default class SideNavbar extends Component<
  SideNavBarProps,
  SideNavBarState,
  { user: { email: string; accesstype: string; uid: string } }
> {
  constructor(props: SideNavBarProps) {
    super(props);
    this.state = {
      isOpen: false,
      selecteditem: "Info",
      profile: null,
    };
  }

  visibilityarray: any =
    window.location.pathname == "/"
      ? ["Devices", "Profile", "logout"]
      : window.location.pathname.startsWith("/") &&
        window.location.hash.length > 15
      ? [
          "Inventory",
          "Monitor",
          "RealTime",
          "Control",
          "Info",
          "Viewers",
          "logout",
        ]
      : window.location.pathname.startsWith("/") &&
        window.location.pathname.length > 15
      ? [
          "Devices",
          "Profile",
          "Inventory",
          "Monitor",
          "RealTime",
          "Control",
          "Info",
          "Viewers",
          "logout",
        ]
      : window.location.pathname.startsWith("/profile")
      ? ["Devices", "Profile", "logout"]
      : [];

  dashboard = [
    <svg
      width="20"
      height="20"
      viewBox="0 0 20 20"
      xmlns="http://www.w3.org/2000/svg"
      key={0}
    >
      <path
        d="M3 4C3 3.44772 3.44772 3 4 3H16C16.5523 3 17 3.44772 17 4V6C17 6.55228 16.5523 7 16 7H4C3.44772 7 3 6.55228 3 6V4Z"
        fill={""}
      ></path>
      <path
        d="M3 10C3 9.44771 3.44772 9 4 9H10C10.5523 9 11 9.44771 11 10V16C11 16.5523 10.5523 17 10 17H4C3.44772 17 3 16.5523 3 16V10Z"
        fill={""}
      ></path>
      <path
        d="M14 9C13.4477 9 13 9.44771 13 10V16C13 16.5523 13.4477 17 14 17H16C16.5523 17 17 16.5523 17 16V10C17 9.44771 16.5523 9 16 9H14Z"
        fill={""}
      ></path>
    </svg>,
  ];

  toggleDrawer = (open: boolean) => () => {
    this.setState({ isOpen: open });
  };

  handleItemClick = (item: string) => {
    this.props.onItemClick(item);
    this.setState({ isOpen: false });
  };

  componentDidMount(): void {
    var { profile } = this.state;

    try {
      profile = getCookie("profile");

      profile = JSON.parse(profile);

      this.setState({ profile, selecteditem: profile.name });
    } catch {
      window.location.replace("/login");
      return;
    }
  }

  render() {
    const { selecteditem } = this.state;

    return (
      <div>
        <div className="brand">
          <img src={logo} alt="" />
          <span>{selecteditem}</span>
        </div>
        <hr />
        <Menu theme="light" mode="inline">
          <Menu.Item
            key="1"
            style={{
              display: this.visibilityarray.includes("Devices")
                ? "Block"
                : "none",
            }}
          >
            <NavLink replace to={"/"}>
              <span
                className="icon"
                style={{
                  background: "",
                  backgroundColor:
                    selecteditem == "Devices" ? "#1890ff" : "white",
                }}
              >
                <img
                  style={{ height: "24px", width: "24px" }}
                  src={
                    "https://img.icons8.com/fluency/48/raspberry-pi-zero.png"
                  }
                />
              </span>
              <span className="label">Devices</span>
            </NavLink>
          </Menu.Item>

          <Menu.Item
            key="2"
            style={{
              display: this.visibilityarray.includes("Info") ? "Block" : "none",
            }}
            onClick={() => this.handleItemClick("Info")}
          >
            <NavLink onClick={(e)=>e.preventDefault()} to="">
              <span
                className="icon"
                style={{
                  background: "",
                  backgroundColor: selecteditem == "Info" ? "#1890ff" : "white",
                }}
              >
                <img
                  style={{ height: "24px", width: "24px" }}
                  src={"https://img.icons8.com/fluency/48/info-squared.png"}
                />
              </span>
              <span className="label">Device Info</span>
            </NavLink>
          </Menu.Item>

          <Menu.Item
            key="3"
            style={{
              display: this.visibilityarray.includes("Inventory")
                ? "Block"
                : "none",
            }}
            onClick={() => this.handleItemClick("Inventory")}
          >
            <NavLink onClick={(e)=>e.preventDefault()} to="">
              <span
                className="icon"
                style={{
                  background: "",
                  backgroundColor:
                    selecteditem == "Inventory" ? "#1890ff" : "white",
                }}
              >
                <img
                  style={{ height: "24px", width: "24px" }}
                  src={"https://img.icons8.com/fluency/48/ipad-mini.png"}
                />
              </span>
              <span className="label">Inventory</span>
            </NavLink>
          </Menu.Item>
          <Menu.Item
            key="4"
            style={{
              display: this.visibilityarray.includes("Monitor")
                ? "Block"
                : "none",
            }}
            onClick={() => this.handleItemClick("Monitor")}
          >
            <NavLink onClick={(e)=>e.preventDefault()} to="">
              <span
                className="icon"
                style={{
                  background: "",
                  backgroundColor:
                    selecteditem == "Monitor" ? "#1890ff" : "white",
                }}
              >
                <img
                  style={{ height: "24px", width: "24px" }}
                  src={"https://img.icons8.com/fluency/48/system-task.png"}
                />
              </span>
              <span className="label">Monitor</span>
            </NavLink>
          </Menu.Item>

          <Menu.Item
            key="5"
            style={{
              display: this.visibilityarray.includes("RealTime")
                ? "Block"
                : "none",
            }}
            onClick={() => this.handleItemClick("RealTime")}
          >
            <NavLink onClick={(e)=>e.preventDefault()} to="">
              <span
                className="icon"
                style={{
                  background: "",
                  backgroundColor:
                    selecteditem == "RealTime" ? "#1890ff" : "white",
                }}
              >
                <img
                  style={{ height: "24px", width: "24px" }}
                  src={
                    "https://img.icons8.com/fluency/48/realtime-protection.png"
                  }
                />
              </span>
              <span className="label">Real Time</span>
            </NavLink>
          </Menu.Item>

          <Menu.Item
            key="6"
            style={{
              display: this.visibilityarray.includes("Control")
                ? "Block"
                : "none",
            }}
            onClick={() => this.handleItemClick("Control")}
          >
            <NavLink onClick={(e)=>e.preventDefault()} to="">
              <span
                className="icon"
                style={{
                  background: "",
                  backgroundColor:
                    selecteditem == "Control" ? "#1890ff" : "white",
                }}
              >
                <img
                  style={{ height: "24px", width: "24px" }}
                  src={
                    "https://img.icons8.com/fluency/48/vertical-settings-mixer.png"
                  }
                />
              </span>
              <span className="label">Control</span>
            </NavLink>
          </Menu.Item>

          <Menu.Item
            key="7"
            style={{
              display: this.visibilityarray.includes("Viewers")
                ? "Block"
                : "none",
            }}
            onClick={() => this.handleItemClick("Viewers")}
          >
            <NavLink onClick={(e)=>e.preventDefault()} to="">
              <span
                className="icon"
                style={{
                  background: "",
                  backgroundColor:
                    selecteditem == "Viewers" ? "#1890ff" : "white",
                }}
              >
                <img
                  style={{ height: "24px", width: "24px" }}
                  src={"https://img.icons8.com/fluency/48/purposeful--user.png"}
                />
              </span>
              <span className="label">Viewers</span>
            </NavLink>
          </Menu.Item>

          <Menu.Item
            key="8"
            style={{
              display: this.visibilityarray.includes("Profile")
                ? "Block"
                : "none",
            }}
          >
            <NavLink to="/profile">
              <span
                className="icon"
                style={{
                  background: "",
                  backgroundColor:
                    selecteditem == "Profile" ? "#1890ff" : "white",
                }}
              >
                <img
                  style={{ height: "24px", width: "24px" }}
                  src={
                    "https://img.icons8.com/fluency/48/admin-settings-male--v1.png"
                  }
                />
              </span>
              <span className="label">Profile</span>
            </NavLink>
          </Menu.Item>
          <Menu.Item
            key="9"
            style={{
              display: this.visibilityarray.includes("logout")
                ? "Block"
                : "none",
            }}
          >
            <NavLink
              to="/login"
              onClick={() => {
                window.localStorage.clear();
                // Function to clear all cookies
                function clearAllCookies() {
                  // Get all cookies
                  const cookies = document.cookie.split(";");

                  // Loop through cookies and set their expiration to the past
                  cookies.forEach((cookie) => {
                    const cookieParts = cookie.split("=");
                    const cookieName = cookieParts[0].trim();
                    document.cookie = `${cookieName}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
                  });
                }

                // Call the function to clear all cookies
                clearAllCookies();
              }}
            >
              <span
                className="icon"
                style={{
                  background: "",
                  backgroundColor:
                    selecteditem == "logout" ? "#1890ff" : "white",
                }}
              >
                <img
                  style={{ height: "24px", width: "24px" }}
                  src={"https://img.icons8.com/fluency/96/imac-exit-1.png"}
                />
              </span>
              <span className="label">Logout</span>
            </NavLink>
          </Menu.Item>
        </Menu>
        <div className="aside-footer" style={{ paddingTop: "0px" }}>
          <div
            className="footer-box"
            style={{
              background: "color",
            }}
          >
            <span className="icon">{this.dashboard}</span>
            <h6>Need Help?</h6>
            <p>Reach us on </p>
            <a
              style={{ marginRight: "10px" }}
              href="https://mail.google.com/mail/?view=cm&fs=1&to=warebotcare@gmail.com"
              target="_blank"
            >
              <img
                style={{ height: "30px", width: "30px" }}
                src="https://img.icons8.com/fluency/96/gmail.png"
              />
            </a>
            <a href="https://twitter.com/CareyJoehln" target="_blank">
              <img
                style={{ height: "30px", width: "30px" }}
                src="https://img.icons8.com/fluency/96/twitterx--v1.png"
              />
            </a>
          </div>
        </div>
      </div>
    );
  }
}
