import React, { Component } from "react";

export default class notFound extends Component {
  render() {
    return (
      <div>
        Oops!! Not found <a href="/">Back to Home</a>
      </div>
    );
  }
}