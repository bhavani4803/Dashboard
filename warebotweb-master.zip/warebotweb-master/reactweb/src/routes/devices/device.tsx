import firebase from "firebase";
import React, { Component } from "react";
import { Bar, Doughnut, Line, Pie } from "react-chartjs-2";
import icon2 from "../../assets/logo.jpeg";
import SaveIcon from "@mui/icons-material/Save";

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from "chart.js";
import {
  Autocomplete,
  Avatar,
  Box,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Divider,
  FormControl,
  FormControlLabel,
  FormGroup,
  IconButton,
  InputAdornment,
  InputLabel,
  Link,
  List,
  ListItem,
  ListItemText,
  MenuItem,
  Modal,
  OutlinedInput,
  Select,
  Slide,
  Slider,
  Snackbar,
  Stack,
  Switch,
  SwitchProps,
  Tab,
  Tabs,
  TextField,
  Typography,
  styled,
} from "@mui/material";
import Lottie from "react-lottie-player";
import animationData from "../../lotties/graphload.json";
import nographdata from "../../lotties/nograph.json";
import { getCookie } from "../../controller/cookie.controller";
import Button from "@mui/material/Button";

import Monitor from "@mui/icons-material/MonitorHeartTwoTone";
import Stream from "@mui/icons-material/StreamTwoTone";
import Control from "@mui/icons-material/TuneTwoTone";
import { AccountCircle } from "@mui/icons-material";
import CloudSync from "@mui/icons-material/CloudSyncTwoTone";
import LoadingButton from "@mui/lab/LoadingButton";
// import LoadingButton from '@mui/lab/LoadingButton';
import highhum from "../../assets/highhum.svg";
import highco2 from "../../assets/highco2.svg";
import lowco2 from "../../assets/lowco2.svg";
import setpoints from "../../assets/setpoints.svg";
import { TransitionProps } from "@mui/material/transitions";
import { error } from "console";
import DeleteIcon from "@mui/icons-material/Delete";
import { Layout, Drawer, Col, Row, Card } from "antd";
import Sider from "antd/es/layout/Sider";
import SideNavbar from "../../SideNavbar/SideNavbar";

import ReactApexChart from "react-apexcharts";
import { MinusOutlined } from "@ant-design/icons";
import Paragraph from "antd/es/skeleton/Paragraph";
import html2canvas from "html2canvas";
import pdfConverter, { jsPDF } from "jspdf";
import Meta from "antd/es/card/Meta";
import TableGrid from "../../AdminNavbar/components/TableGrid";
import {
  DataGrid,
  GridToolbarContainer,
  GridToolbarExport,
} from "@mui/x-data-grid";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

const IOSSwitch = styled((props: SwitchProps) => (
  <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} />
))(({ theme }) => ({
  width: 42,
  height: 26,
  padding: 0,
  "& .MuiSwitch-switchBase": {
    padding: 0,
    margin: 2,
    transitionDuration: "300ms",
    "&.Mui-checked": {
      transform: "translateX(16px)",
      color: "#fff",
      "& + .MuiSwitch-track": {
        backgroundColor: theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
        opacity: 1,
        border: 0,
      },
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: 0.5,
      },
    },
    "&.Mui-focusVisible .MuiSwitch-thumb": {
      color: "#33cf4d",
      border: "6px solid #fff",
    },
    "&.Mui-disabled .MuiSwitch-thumb": {
      color:
        theme.palette.mode === "light"
          ? theme.palette.grey[100]
          : theme.palette.grey[600],
    },
    "&.Mui-disabled + .MuiSwitch-track": {
      opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
    },
  },
  "& .MuiSwitch-thumb": {
    boxSizing: "border-box",
    width: 22,
    height: 22,
  },
  "& .MuiSwitch-track": {
    borderRadius: 26 / 2,
    backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
    opacity: 1,
    transition: theme.transitions.create(["background-color"], {
      duration: 500,
    }),
  },
}));

const Transition = React.forwardRef(function Transition(
  props: TransitionProps & {
    children: React.ReactElement<any, any>;
  },
  ref: React.Ref<unknown>
) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const dollor = [
  <svg
    width="22"
    height="22"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    key={0}
  >
    <path
      d="M8.43338 7.41784C8.58818 7.31464 8.77939 7.2224 9 7.15101L9.00001 8.84899C8.77939 8.7776 8.58818 8.68536 8.43338 8.58216C8.06927 8.33942 8 8.1139 8 8C8 7.8861 8.06927 7.66058 8.43338 7.41784Z"
      fill="#fff"
    ></path>
    <path
      d="M11 12.849L11 11.151C11.2206 11.2224 11.4118 11.3146 11.5666 11.4178C11.9308 11.6606 12 11.8861 12 12C12 12.1139 11.9308 12.3394 11.5666 12.5822C11.4118 12.6854 11.2206 12.7776 11 12.849Z"
      fill="#fff"
    ></path>
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10C2 14.4183 5.58172 18 10 18ZM11 5C11 4.44772 10.5523 4 10 4C9.44772 4 9 4.44772 9 5V5.09199C8.3784 5.20873 7.80348 5.43407 7.32398 5.75374C6.6023 6.23485 6 7.00933 6 8C6 8.99067 6.6023 9.76515 7.32398 10.2463C7.80348 10.5659 8.37841 10.7913 9.00001 10.908L9.00002 12.8492C8.60902 12.7223 8.31917 12.5319 8.15667 12.3446C7.79471 11.9275 7.16313 11.8827 6.74599 12.2447C6.32885 12.6067 6.28411 13.2382 6.64607 13.6554C7.20855 14.3036 8.05956 14.7308 9 14.9076L9 15C8.99999 15.5523 9.44769 16 9.99998 16C10.5523 16 11 15.5523 11 15L11 14.908C11.6216 14.7913 12.1965 14.5659 12.676 14.2463C13.3977 13.7651 14 12.9907 14 12C14 11.0093 13.3977 10.2348 12.676 9.75373C12.1965 9.43407 11.6216 9.20873 11 9.09199L11 7.15075C11.391 7.27771 11.6808 7.4681 11.8434 7.65538C12.2053 8.07252 12.8369 8.11726 13.254 7.7553C13.6712 7.39335 13.7159 6.76176 13.354 6.34462C12.7915 5.69637 11.9405 5.26915 11 5.09236V5Z"
      fill="#fff"
    ></path>
  </svg>,
];

const heart = [
  <svg
    width="22"
    height="22"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    key={0}
  >
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M3.17157 5.17157C4.73367 3.60948 7.26633 3.60948 8.82843 5.17157L10 6.34315L11.1716 5.17157C12.7337 3.60948 15.2663 3.60948 16.8284 5.17157C18.3905 6.73367 18.3905 9.26633 16.8284 10.8284L10 17.6569L3.17157 10.8284C1.60948 9.26633 1.60948 6.73367 3.17157 5.17157Z"
      fill="#fff"
    ></path>
  </svg>,
];
const cart = [
  <svg
    width="22"
    height="22"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    key={0}
  >
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M10 2C7.79086 2 6 3.79086 6 6V7H5C4.49046 7 4.06239 7.38314 4.00612 7.88957L3.00612 16.8896C2.97471 17.1723 3.06518 17.455 3.25488 17.6669C3.44458 17.8789 3.71556 18 4 18H16C16.2844 18 16.5554 17.8789 16.7451 17.6669C16.9348 17.455 17.0253 17.1723 16.9939 16.8896L15.9939 7.88957C15.9376 7.38314 15.5096 7 15 7H14V6C14 3.79086 12.2091 2 10 2ZM12 7V6C12 4.89543 11.1046 4 10 4C8.89543 4 8 4.89543 8 6V7H12ZM6 10C6 9.44772 6.44772 9 7 9C7.55228 9 8 9.44772 8 10C8 10.5523 7.55228 11 7 11C6.44772 11 6 10.5523 6 10ZM13 9C12.4477 9 12 9.44772 12 10C12 10.5523 12.4477 11 13 11C13.5523 11 14 10.5523 14 10C14 9.44772 13.5523 9 13 9Z"
      fill="#fff"
    ></path>
  </svg>,
];

class Devices extends Component {
  state: Readonly<{
    macaddress: string;
    datasetdata: any;
    setpoints: any;
    hasgraphdata: boolean;
    fromdate: any;
    todate: any;
    mindate: string;
    maxdate: string;
    predata: any;
    initdataset: any;
    isSinglegraphdisplay: boolean;
    firstdatemin: any;
    firstdatemax: any;
    moddalisopened: boolean;
    nographfound: string;
    filterdropdown: any;
    customopen: boolean;
    deviceinfo: any;
    devicename: String;
    tabsval: any;
    realtime: any;
    uploadloading: boolean;
    deviceimageurl: string;
    openinventorymodal: any;
    addinventorydata: any;
    inventoryuploadloading: any;
    visible: boolean;
    navbarclickcontrol: any;
    countinfo: any;
    devicestatus: any;
    openviewermodal: any;
    addviewerdata: any;
    viewerinfo: any;
    userslistforviewerpermission: any;
    vieweruploadloading: any;
    profile: any;
    isviewer: any;
    snackbar: any;
    warehousedata: any;
    warehousedataloading: any;
    datatableloading: any;
    openexitinventorymodal: any;
    currentnventerydata: any;
    searchuserbymail: any;
    relaystogglestate:any;
  }>;

  lineChart = {
    series: [
      {
        name: "Mobile apps",
        data: [350, 40, 300, 220, 500, 250, 400, 230, 500],
        offsetY: 0,
      },
      {
        name: "Websites",
        data: [30, 90, 40, 140, 290, 290, 340, 230, 400],
        offsetY: 0,
      },
    ],

    options: {
      chart: {
        width: "100%",
        height: 350,
        toolbar: {
          show: false,
        },
      },

      legend: {
        show: false,
      },

      dataLabels: {
        enabled: false,
      },
      stroke: {
        curve: "smooth",
      },

      yaxis: {
        labels: {
          style: {
            fontSize: "14px",
            fontWeight: 600,
            colors: ["#8c8c8c"],
          },
        },
      },

      xaxis: {
        labels: {
          style: {
            fontSize: "14px",
            fontWeight: 600,
            colors: [
              "#8c8c8c",
              "#8c8c8c",
              "#8c8c8c",
              "#8c8c8c",
              "#8c8c8c",
              "#8c8c8c",
              "#8c8c8c",
              "#8c8c8c",
              "#8c8c8c",
            ],
          },
        },
        categories: [
          "Feb",
          "Mar",
          "Apr",
          "May",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Oct",
        ],
      },

      tooltip: {
        y: {
          formatter: function (val: any) {
            return val;
          },
        },
      },
    },
  };
  firebaseConfig = {
    apiKey: "AIzaSyALIxWc98nMBPC5opE4cG_o-4zF3epKwDQ",
    authDomain: "warebot-6957c.firebaseapp.com",
    databaseURL: "https://warebot-6957c-default-rtdb.firebaseio.com",
    projectId: "warebot-6957c",
    storageBucket: "warebot-6957c.appspot.com",
    messagingSenderId: "772347476312",
    appId: "1:772347476312:web:dd68b3449643fc8c16cd2d",
    measurementId: "G-HNR0VKT0PD",
  };

  markings = [
    {
      value: 0,
      label: "0",
    },
    {
      value: 1,
      label: "1",
    },
    {
      value: 3,
      label: "3",
    },
    {
      value: 5,
      label: "5",
    },
    {
      value: 10,
      label: "10",
    },
    {
      value: 15,
      label: "15",
    },
    {
      value: 20,
      label: "20",
    },
    {
      value: 30,
      label: "30",
    },
    {
      value: 40,
      label: "40",
    },
    {
      value: 50,
      label: "60",
    },
    {
      value: 70,
      label: "70",
    },
    {
      value: 80,
      label: "80",
    },
    {
      value: 90,
      label: "90",
    },
  ];

  customSort = (a: any, b: any) => {
    const partsA = a.split("_");
    const partsB = b.split("_");

    // Split date parts by hyphen
    const dateA = partsA[0].split("-");
    const dateB = partsB[0].split("-");

    // Combine date and time into sortable format
    const dateAndTimeA = `${dateA[2]}-${dateA[0]}-${dateA[1]} ${partsA[1]}`;
    const dateAndTimeB = `${dateB[2]}-${dateB[0]}-${dateB[1]} ${partsB[1]}`;

    // Convert to JavaScript Date objects and compare
    const dateObjA: any = new Date(dateAndTimeA);
    const dateObjB: any = new Date(dateAndTimeB);

    return dateObjA - dateObjB;
  };

  constructor(props: any) {
    super(props);

    this.state = {
      macaddress: "",
      datasetdata: {
        labels: [],
        dataset: [
          {
            label: "Temperature",
            data: [],
            borderWidth: 1,
            borderColor: "rgb(255, 99, 132)",
            backgroundColor: "rgba(255, 99, 132, 0.5)",
          },
          {
            label: "Humidity",
            data: [],
            borderWidth: 1,
            borderColor: "rgb(53, 162, 235)",
            backgroundColor: "rgba(53, 162, 235, 0.5)",
          },
          {
            label: "ppm",
            data: [],
            borderWidth: 1,
            borderColor: "rgb(53, 162, 235)",
            backgroundColor: "rgba(17, 245, 17, 0.5)",
          },
        ],
      },
      setpoints: {},
      hasgraphdata: false,
      fromdate: "",
      todate: "",
      mindate: "",
      maxdate: "",
      predata: {},
      initdataset: {
        labels: [],
        dataset: [
          {
            label: "Temperature",
            data: [],
            borderWidth: 1,
            borderColor: "rgb(255, 99, 132)",
            backgroundColor: "rgba(255, 99, 132, 0.5)",
          },
          {
            label: "Humidity",
            data: [],
            borderWidth: 1,
            borderColor: "rgb(53, 162, 235)",
            backgroundColor: "rgba(53, 162, 235, 0.5)",
          },
          {
            label: "ppm",
            data: [],
            borderWidth: 1,
            borderColor: "rgb(53, 162, 235)",
            backgroundColor: "rgba(17, 245, 17, 0.5)",
          },
        ],
      },
      isSinglegraphdisplay: false,
      firstdatemin: null,
      firstdatemax: null,
      moddalisopened: false,
      nographfound: "init",
      filterdropdown: 0,
      customopen: false,
      deviceinfo: null,
      devicename: "",
      tabsval: 0,
      realtime: {
        labels: ["Temperatute", "Humidity", "Co2"],
        datasets: [
          {
            label: "Realtime device",
            data: [12, 19, 3],
            backgroundColor: [
              "rgba(255, 99, 132, 0.2)",
              "rgba(54, 162, 235, 0.2)",
              "rgba(75, 192, 192, 0.2)",
            ],
            borderColor: [
              "rgba(255, 99, 132, 1)",
              "rgba(54, 162, 235, 1)",
              "rgba(75, 192, 192, 1)",
            ],
            borderWidth: 1,
          },
        ],
      },
      uploadloading: false,
      deviceimageurl:
        "https://img.icons8.com/external-those-icons-flat-those-icons/96/external-Add-Image-images-and-image-files-those-icons-flat-those-icons.png",
      openinventorymodal: false,
      addinventorydata: {
        item: "",
        itemtype: "",
        itemqty: "0",
        itemweight: "0",
        totalweight: "0",
        description: "",
        entrydate: "",
        exitdate: "",
        marketval: "",
        timestamp: "",
      },
      inventoryuploadloading: false,
      visible: false,
      navbarclickcontrol: [true, false, false, false, false, false],
      countinfo: [
        {
          today: "Status",
          title: "Offline",
          icon: heart,
          bnb: "redtext",
        },
        {
          today: "Viewers Count",
          title: "0",
          icon: dollor,
          bnb: "bnb2",
        },
        {
          today: "Pack ends at",
          title: "comming soon...",
          icon: cart,
          bnb: "bnb2",
        },
      ],
      devicestatus: 0,
      openviewermodal: false,
      addviewerdata: {
        uid: "",
        mail: "",
        viewertype: 10,
        warehousename: "",
        space: "",
        others: "",
      },
      viewerinfo: null,
      userslistforviewerpermission: [],
      vieweruploadloading: false,
      profile: null,
      isviewer: false,
      snackbar: {
        open: false,
        text: "sample text",
      },
      warehousedata: {
        name: "",
        address: "",
        loc: "",
        idealdata: {
          gas: 0,
          humid: 0,
          temp: 0,
        },
      },
      warehousedataloading: false,
      datatableloading: true,
      openexitinventorymodal: false,
      currentnventerydata: {},
      searchuserbymail: "",
      relaystogglestate:[]
    };
  }

  filterDataByDateRange = (dateArray: any, startDate: any, endDate: any) => {
    startDate = new Date(startDate);
    endDate = new Date(endDate);

    return dateArray.filter((dateStr: any) => {
      const dateParts = dateStr.split("_")[0].split("-");
      const year = parseInt(dateParts[2], 10);
      const month = parseInt(dateParts[0], 10) - 1; // Month is zero-based
      const day = parseInt(dateParts[1], 10);
      const date = new Date(year, month, day);

      return date >= startDate && date <= endDate;
    });
  };

  handleFromDateChange = (e: any) => {
    const newValue = e.target.value; // Get the new date value
    const date = new Date(newValue);
    date.setMonth(date.getMonth() + 1);
    if (date.getMonth() === 0) {
      date.setFullYear(date.getFullYear() + 1);
    }

    var newDate =
      date.getDate().toString().length > 1
        ? date.getDate()
        : "0" + date.getDate();
    var newMonth =
      (date.getMonth() + 1).toString().length > 1
        ? date.getMonth() + 1
        : "0" + (date.getMonth() + 1);

    this.setState({
      fromdate: newValue,
      mindate: newValue,
      maxdate: date.getFullYear() + "-" + newMonth + "-" + newDate,
    });
  };

  handletoDateChange = (e: any) => {
    const newValue = e.target.value; // Get the new date value
    this.setState({ todate: newValue });
  };
  handlefilterresetclick = () => {
    const { initdataset } = this.state;
    console.log(initdataset);
    this.setState({
      datasetdata: JSON.parse(JSON.stringify(initdataset)),
      filterdropdown: 0,
      customopen: false,
    });
  };

  handlefilterclick = () => {
    const { fromdate, todate, datasetdata, predata, initdataset } = this.state;
    if (fromdate.length <= 0) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "from date selection required";
      this.setState(snackbar);
      return;
    }

    if (todate.length <= 0) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "to date selection required";
      this.setState(snackbar);
      return;
    }

    var datesarray = this.filterDataByDateRange(
      JSON.parse(JSON.stringify(initdataset)).labels,
      fromdate,
      todate
    );
    console.log(JSON.parse(JSON.stringify(initdataset)).labels, datesarray);
    datasetdata.labels = [];
    datasetdata.dataset[0].data = [];
    datasetdata.dataset[1].data = [];
    datasetdata.dataset[2].data = [];

    datesarray.map((e: any) => {
      datasetdata.labels.push(e);
      datasetdata.dataset[0].data.push(predata.graph[e].temp);
      datasetdata.dataset[1].data.push(predata.graph[e].hmd);
      datasetdata.dataset[2].data.push(predata.graph[e].co2);
    });

    console.log(datasetdata);
    this.setState({ datasetdata });
  };

  componentDidMount(): void {
    var {
      datasetdata,
      setpoints,
      initdataset,
      realtime,
      profile,
      countinfo,
      deviceinfo,
      datatableloading,
      relaystogglestate,
      viewerinfo,
    } = this.state;

    var token_: any = getCookie("__tkn__");
    if (!token_) {
      window.location.href = "/login";
    }

    try {
      profile = getCookie("profile");

      profile = JSON.parse(profile);
      this.setState({ profile });
    } catch {
      window.location.replace("/login");
      return;
    }

    var _this = this;

    var urlSearchParams = decodeURIComponent(window.location.pathname);

    if (urlSearchParams.split(":").length == 6) {
      this.setState({
        hasmac: true,
        macaddress: decodeURIComponent(urlSearchParams.replace("/", "")),
      });
    } else {
      window.location.href = "/";
    }

    var hashmap = window.location.hash;
    if (hashmap.length > 16) {
      profile.uid = hashmap.replace("#", "");
      token_ = hashmap.replace("#", "");

      this.setState({
        profile,
      });
    }

    firebase.apps.length <= 0
      ? firebase.initializeApp(this.firebaseConfig)
      : firebase.app();

    const database = firebase.database();

    var _this = this;

    database.ref("Users").on("value", (es) => {
      console.log(es.val());
      const{predata} = _this.state
      if(predata&&predata["pack"] == 10 && (profile && profile.isadmin==false)){
      
        return
      }

      var data = es.val();

      if (data == null) {
        this.setState({ view: "data not found" });
      } else if (data.length <= 0) {
        this.setState({ view: "no data found" });
      } else {
        var usersdata: any = [];

        Object.keys(data)
          .filter((e: any) => data[e].profile)
          .map((ee: any, id: number) => {
            data[ee].profile["uid"] = ee;
            data[ee].profile["id"] = id;
            data[ee].profile["label"] = data[ee].profile.mail;
            
            usersdata.push(data[ee].profile);
            
          });
        console.log(usersdata);

        _this.setState({ userslistforviewerpermission: usersdata, countinfo });
      }
    });

    database
      .ref("Users")
      .child(token_)
      .child("devices")
      .child(decodeURIComponent(urlSearchParams.replace("/", "")))
      .once("value", (es) => {
        console.log(es.val());
        const{predata} = _this.state
        if(predata&&predata["pack"] == 10&& (profile && profile.isadmin==false) ){
        
          return
        }

        var devicedata = es.val();
        console.log("sspp",devicedata);
        

      
        
        _this.setState({ devicename: es.val()});
      })
      .catch((e) => {
        console.error(e);
      });
    const accountsRef = database
      .ref("Device")
      .child(decodeURIComponent(urlSearchParams.replace("/", ""))); // Replace 'accounts' with the actual path to your data in the database.
    accountsRef.once("value", function (snapshot) {
      // This function will be called whenever data changes
      var messages = snapshot.val();
      console.log("New data received:", messages);

      if (!messages) {
        setpoints = {
          MaxPPM: 0,
          MaxTemp: 0,
          Maxhum: 0,
          MinPPM: 0,
          MinTemp: 0,
          Minhum: 0,
          interval: 0,
        };
        return;
      }

      messages["pack"] = messages["setpoints"]["pack"];

      
      var packstatus = messages["pack"]?messages["pack"]:10;
      
      if (packstatus == 10) {
        countinfo[2].title = "Expired";
        countinfo[2].today = "Your Pack status";

      } else if (packstatus == 20) {
        countinfo[2].title = "Instant";
        countinfo[2].today = "Your Pack status";
      } else if (packstatus == 30) {
        countinfo[2].title = "Trial";
        countinfo[2].today = "Your Pack status";
      } else if (packstatus == 40) {
        countinfo[2].title = "1 month";
        countinfo[2].today = "Your Pack status";
      } else if (packstatus == 50) {
        countinfo[2].title = "3 months";
        countinfo[2].today = "Your Pack status";
      } else if (packstatus == 60) {
        countinfo[2].title = "6 months";
        countinfo[2].today = "Your Pack status";
      } else if (packstatus == 70) {
        countinfo[2].title = "1 year";
        countinfo[2].today = "Your Pack status";
      }
      
      _this.setState({countinfo})
      
      if(packstatus == 10 && (profile && profile.isadmin==false)){
        alert("pack expired")
        _this.setState({countinfo})
        
        return
      }
      
      
      if (messages.viewers) {
        Object.keys(messages.viewers).map((e) => {
          if (e == profile.uid) {
            _this.setState({ isviewer: true });
          }
        });
      }
      if (!messages.graph) {
        _this.setState({ nographfound: "notfound" });
        return;
      }

      setpoints = {
        MaxPPM: messages["setpoints"]["MaxPPM"]
          ? messages["setpoints"]["MaxPPM"]
          : 0,
        MaxTemp: messages["setpoints"]["MaxTemp"]
          ? messages["setpoints"]["MaxTemp"]
          : 0,
        Maxhum: messages["setpoints"]["Maxhum"]
          ? messages["setpoints"]["Maxhum"]
          : 0,
        MinPPM: messages["setpoints"]["MinPPM"]
          ? messages["setpoints"]["MinPPM"]
          : 0,
        MinTemp: messages["setpoints"]["MinTemp"]
          ? messages["setpoints"]["MinTemp"]
          : 0,
        Minhum: messages["setpoints"]["Minhum"]
          ? messages["setpoints"]["Minhum"]
          : 0,
        interval: messages["setpoints"]["interval"]
          ? messages["setpoints"]["interval"]
          : 0,
      };

      const sortedTimestamps = Object.keys(messages.graph).sort(
        _this.customSort
      );

      sortedTimestamps.map((e: any) => {
        datasetdata.labels.push(e);
        datasetdata.dataset[0].data.push(messages.graph[e].temp);
        datasetdata.dataset[1].data.push(messages.graph[e].hmd);
        datasetdata.dataset[2].data.push(messages.graph[e].co2);
        initdataset.labels.push(e);
        initdataset.dataset[0].data.push(messages.graph[e].temp);
        initdataset.dataset[1].data.push(messages.graph[e].hmd);
        initdataset.dataset[2].data.push(messages.graph[e].co2);
      });

      console.log(datasetdata);

      // Initialize variables to store the minimum and maximum dates
      let minDate = new Date(initdataset.labels[0].split("_"));
      let maxDate = new Date(initdataset.labels[0].split("_"));

      // Iterate through the date-time strings to find the minimum and maximum dates
      for (const dateStr of initdataset.labels) {
        const currentDate = new Date(dateStr.split("_")[0]);

        if (currentDate < minDate) {
          minDate = currentDate; // Update minDate if a smaller date is found
        }

        if (currentDate > maxDate) {
          maxDate = currentDate; // Update maxDate if a larger date is found
        }
      }

      console.log("Minimum Date:", minDate);
      console.log("Maximum Date:", maxDate);

      var newDate =
        minDate.getDate().toString().length > 1
          ? minDate.getDate()
          : "0" + minDate.getDate();
      var newMonth =
        (minDate.getMonth() + 1).toString().length > 1
          ? minDate.getMonth() + 1
          : "0" + (minDate.getMonth() + 1);

      var newminDate = minDate.getFullYear() + "-" + newMonth + "-" + newDate;

      var newDate =
        maxDate.getDate().toString().length > 1
          ? maxDate.getDate()
          : "0" + maxDate.getDate();
      var newMonth =
        (maxDate.getMonth() + 1).toString().length > 1
          ? maxDate.getMonth() + 1
          : "0" + (maxDate.getMonth() + 1);

      var newmaxDate = maxDate.getFullYear() + "-" + newMonth + "-" + newDate;

      _this.setState({ firstdatemin: newminDate, firstdatemax: newmaxDate });

      if (messages["image"]) {
        _this.setState({
          deviceimageurl: messages["image"],
        });
      }

      console.log(messages, messages["warehousedata"]);
      setpoints["tempstate"] = setpoints["tempstate"]
        ? setpoints["tempstate"]
        : true;
      setpoints["humidstate"] = setpoints["humidstate"]
        ? setpoints["humidstate"]
        : true;
      setpoints["ppmstate"] = setpoints["ppmstate"]
        ? setpoints["ppmstate"]
        : true;

      if (messages["info"] && Object.keys(messages["info"]).length > 0) {
        messages["info"] = Object.values(messages["info"]).filter((e:any)=>e["viewermail"]==profile.mail)
        
        var keyss = Object.values(messages["info"]);


        deviceinfo = keyss;
        console.log(deviceinfo);
        
        let id = 1;
        for (const key in deviceinfo) {
          deviceinfo[key].id = id++;
          
        }
      }


      relaystogglestate = messages["relays"]?messages["relays"]:[]
      if (messages["viewers"] && Object.keys(messages["viewers"]).length > 0) {
        var keyss = Object.values(messages["viewers"]);
        viewerinfo = keyss;
        let id = 1;
        for (const key in viewerinfo) {
          viewerinfo[key].id = id++;
        }
      }

      _this.setState({
        datasetdata,
        predata: messages,
        warehousedata: messages["warehousedata"]
          ? messages["warehousedata"]
          : {
              name: " ",
              address: " ",
              loc: " ",
              idealdata: {
                gas: 0,
                humid: 0,
                temp: 0,
              },
            },
        initdataset,
        hasgraphdata: true,
        setpoints,
        nographfound: "found",
        deviceimageurl: messages["image"],
        deviceinfo,
        datatableloading: false,
        relaystogglestate
      });
    });

    accountsRef.child("setpoints").on("value", function (e) {
      var {predata,profile} = _this.state
      
      var jsondata = e.val();
      console.log(jsondata);
      if(predata&&predata["pack"] == 10 && (profile && profile.isadmin==false)){
      
        return
      }

      predata["pack"] = jsondata["pack"];

      _this.setState({ setpoints: jsondata,predata });
    });

    accountsRef.child("graph").on("value", function (e) {
      const { predata, realtime } = _this.state;
      if(predata&&predata["pack"] == 10 && (profile && profile.isadmin==false)){
      
        return
      }
      console.log("surya", e.val());
      var messages = e.val();
      const sortedTimestamps = Object.keys(messages).sort(_this.customSort);

      if (datasetdata.labels.length <= 0) {
        return;
      }
      datasetdata.labels = [];
      datasetdata.dataset[0].data = [];
      datasetdata.dataset[1].data = [];
      datasetdata.dataset[2].data = [];

      initdataset.labels = [];
      initdataset.dataset[0].data = [];
      initdataset.dataset[1].data = [];
      initdataset.dataset[2].data = [];

      console.log(sortedTimestamps);

      sortedTimestamps.map((e: any) => {
        datasetdata.labels.push(e);
        datasetdata.dataset[0].data.push(messages[e].temp);
        datasetdata.dataset[1].data.push(messages[e].hmd);
        datasetdata.dataset[2].data.push(messages[e].co2);
        initdataset.labels.push(e);
        initdataset.dataset[0].data.push(messages[e].temp);
        initdataset.dataset[1].data.push(messages[e].hmd);
        initdataset.dataset[2].data.push(messages[e].co2);
      });

      console.log(datasetdata);

      // Initialize variables to store the minimum and maximum dates
      let minDate = new Date(initdataset.labels[0].split("_"));
      let maxDate = new Date(initdataset.labels[0].split("_"));

      // Iterate through the date-time strings to find the minimum and maximum dates
      for (const dateStr of initdataset.labels) {
        const currentDate = new Date(dateStr.split("_")[0]);

        if (currentDate < minDate) {
          minDate = currentDate; // Update minDate if a smaller date is found
        }

        if (currentDate > maxDate) {
          maxDate = currentDate; // Update maxDate if a larger date is found
        }
      }

      console.log("Minimum Date:", minDate);
      console.log("Maximum Date:", maxDate);

      var newDate =
        minDate.getDate().toString().length > 1
          ? minDate.getDate()
          : "0" + minDate.getDate();
      var newMonth =
        (minDate.getMonth() + 1).toString().length > 1
          ? minDate.getMonth() + 1
          : "0" + (minDate.getMonth() + 1);

      var newminDate = minDate.getFullYear() + "-" + newMonth + "-" + newDate;

      var newDate =
        maxDate.getDate().toString().length > 1
          ? maxDate.getDate()
          : "0" + maxDate.getDate();
      var newMonth =
        (maxDate.getMonth() + 1).toString().length > 1
          ? maxDate.getMonth() + 1
          : "0" + (maxDate.getMonth() + 1);

      var newmaxDate = maxDate.getFullYear() + "-" + newMonth + "-" + newDate;

      _this.setState({ firstdatemin: newminDate, firstdatemax: newmaxDate });
      predata["graph"] = messages;

      realtime.datasets[0].data[0] =
        messages[sortedTimestamps[sortedTimestamps.length - 1]]["temp"];
      realtime.datasets[0].data[1] =
        messages[sortedTimestamps[sortedTimestamps.length - 1]]["hmd"];
      realtime.datasets[0].data[2] =
        messages[sortedTimestamps[sortedTimestamps.length - 1]]["co2"];
      realtime.datasets[0].data[3] =
        messages[sortedTimestamps[sortedTimestamps.length - 1]]["ldr1"];
      realtime.datasets[0].data[4] =
        messages[sortedTimestamps[sortedTimestamps.length - 1]]["ldr2"];
      realtime.datasets[0].data[5] =
        messages[sortedTimestamps[sortedTimestamps.length - 1]]["ldr3"];
      realtime.datasets[0].data[6] =
        messages[sortedTimestamps[sortedTimestamps.length - 1]]["ldr4"];
      realtime.datasets[0].data[7] =
        sortedTimestamps[sortedTimestamps.length - 1];

      console.log("surua", realtime);
      _this.setState({
        datasetdata,
        predata,
        initdataset,
        hasgraphdata: true,
        nographfound: "found",
        realtime,
      });
    });
    accountsRef.child("graph").on("child_added", function (e) {
      const { predata, realtime } = _this.state;
      console.log(profile);
      
      if(predata&&predata["pack"] == 10 && (profile && profile.isadmin==false)){
      
        return
      }
      var data = e.val();

      realtime.datasets[0].data[0] = data["temp"];
      realtime.datasets[0].data[1] = data["hmd"];
      realtime.datasets[0].data[2] = data["co2"];
      realtime.datasets[0].data[3] = data["ldr1"];
      realtime.datasets[0].data[4] = data["ldr2"];
      realtime.datasets[0].data[5] = data["ldr3"];
      realtime.datasets[0].data[6] = data["ldr4"];
      realtime.datasets[0].data[7] = e.key;


      _this.setState({ realtime });
    });

    // accountsRef.child("info").on("value", function (e) {
    //   const { countinfo } = _this.state;

    //   var jsondata = e.val();
    //   console.log(jsondata);

    //   countinfo[2].title = jsondata ? Object.keys(jsondata).length : 0;

    //   _this.setState({ deviceinfo: jsondata, countinfo });
    // });
    accountsRef.child("viewers").on("value", function (e) {
      const{predata} = _this.state
      if(predata&&predata["pack"] == 10 && (profile && profile.isadmin==false)){
      
        return
      }
      var { countinfo, viewerinfo } = _this.state;
      var jsondata = e.val();
      console.log(jsondata);

      countinfo[1].title = jsondata ? Object.keys(jsondata).length : 0;

      if (Object.keys(jsondata).length > 0) {
        var keyss = Object.values(jsondata);
        viewerinfo = keyss;
        let id = 1;
        for (const key in viewerinfo) {
          viewerinfo[key].id = id++;
        }
      }

      _this.setState({ countinfo, viewerinfo });
    });
    accountsRef.child("status").on("value", function (e) {
      const{predata} = _this.state
      if(predata&&predata["pack"] == 10 && (profile && profile.isadmin==false)){
      
        return
      }
      const { countinfo } = _this.state;
      var jsondata = e.val();
      countinfo[0].title = jsondata == 0 ? "Offline" : "Online";
      _this.setState({ devicestatus: jsondata });
    });

    accountsRef.child("relays").on("value", function (e) {
      const{predata} = _this.state
      relaystogglestate = e.val()?e.val():[]
      
      _this.setState({ relaystogglestate });
    });

  }

  // Function to filter data based on a specific time interval
  filterData(data: any, intervalInHours: any) {
    const currentTime: any = new Date();
    const filteredData = data.filter((timestamp: any) => {
      const timestampDate: any = new Date(timestamp.replace("_", "T"));
      const timeDiffInHours = (currentTime - timestampDate) / (1000 * 60 * 60);
      return timeDiffInHours <= intervalInHours;
    });
    return filteredData;
  }

  handleChange = (event: any) => {
    const { filterdropdown, initdataset, datasetdata, predata } = this.state;
    var value = event.target.value;
    var currentData = [];
    this.setState({ customopen: false });

    if (value == 0) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "select a vaild filter option";
      this.setState(snackbar);
      return;
    } else if (value == 1) {
      currentData = this.filterData(
        JSON.parse(JSON.stringify(initdataset)).labels,
        1
      );
    } else if (value == 2) {
      currentData = this.filterData(
        JSON.parse(JSON.stringify(initdataset)).labels,
        3
      );
    } else if (value == 3) {
      currentData = this.filterData(
        JSON.parse(JSON.stringify(initdataset)).labels,
        24
      );
    } else if (value == 4) {
      const oneWeekAgo = new Date();
      oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
      currentData = JSON.parse(JSON.stringify(initdataset)).labels.filter(
        (timestamp: any) => new Date(timestamp.replace("_", "T")) >= oneWeekAgo
      ); // Last 1 week
    } else if (value == 4) {
      const threeWeeksAgo = new Date();
      threeWeeksAgo.setDate(threeWeeksAgo.getDate() - 21);
      currentData = JSON.parse(JSON.stringify(initdataset)).labels.filter(
        (timestamp: any) =>
          new Date(timestamp.replace("_", "T")) >= threeWeeksAgo
      ); // Last 3 weeks
    } else if (value == 6) {
      this.setState({ customopen: true, filterdropdown: event.target.value });
      return;
    }
    if (currentData.length <= 0) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "Data not found";
      this.setState(snackbar);
      return;
    }
    console.log(currentData);

    console.log(JSON.parse(JSON.stringify(initdataset)).labels, currentData);
    datasetdata.labels = [];
    datasetdata.dataset[0].data = [];
    datasetdata.dataset[1].data = [];
    datasetdata.dataset[2].data = [];

    currentData.map((e: any) => {
      datasetdata.labels.push(e);
      datasetdata.dataset[0].data.push(predata.graph[e].temp);
      datasetdata.dataset[1].data.push(predata.graph[e].hmd);
      datasetdata.dataset[2].data.push(predata.graph[e].co2);
    });

    console.log(datasetdata);

    this.setState({ filterdropdown: event.target.value, datasetdata });
  };

  tabshandleChange = (event: React.SyntheticEvent, newValue: number) => {
    this.setState({ tabsval: newValue });
    setTimeout(() => {
      window.scrollTo(0, document.body.scrollHeight);
    }, 100);
  };

  uploadsynchandleClick = () => {
    const { setpoints, macaddress, isviewer } = this.state;

    if (isviewer) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "Invalid previlages";
      this.setState(snackbar);
      return;
    }

    this.setState({ uploadloading: true });

    const database = firebase.database();
    database
      .ref("Device")
      .child(macaddress)
      .child("setpoints")
      .set(setpoints)
      .then((e) => {
        this.setState({ uploadloading: false });
      })
      .catch((e) => {
        const { snackbar } = this.state;
        snackbar.open = true;
        snackbar.text = "unable to update data";
        this.setState(snackbar);
        this.setState({ uploadloading: false });
      });
  };

  inventoryuploadsynchandleClick = (type: any) => {
    const { addinventorydata, macaddress, isviewer ,predata} = this.state;

    if (isviewer) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "Invalid access";
      this.setState(snackbar);

      return;
    }


    if (addinventorydata["item"].length <= 0) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "item name required";
      this.setState(snackbar);
      return;
    }

    if (addinventorydata["itemtype"].length <= 0) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "Item type required";
      this.setState(snackbar);
      return;
    }
    if (addinventorydata["itemqty"].length <= 0) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "Goods/Item quantity required";
      this.setState(snackbar);
      return;
    }

    if (addinventorydata["itemweight"].length <= 0) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "Goods/Item weight required";
      this.setState(snackbar);
      return;
    }

    if (addinventorydata["description"].length <= 0) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "Goods/Item description required";
      this.setState(snackbar);
      return;
    }
    if (addinventorydata["entrydate"].length <= 0) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "start date required";
      this.setState(snackbar);
      return;
    }
    if (addinventorydata["exitdate"].length <= 0) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "end date required";
      this.setState(snackbar);
      return;
    }

    if (addinventorydata["marketval"].length <= 0) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "marketval required";
      this.setState(snackbar);
      return;
    }

    if (addinventorydata["viewermail"].length <= 0) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "Viewer mail id required";
      this.setState(snackbar);
      return;
    }

    
    
    
    var viewerinfo = Object.keys(predata["viewers"]).find((els:any)=>predata["viewers"][els]["mail"] == addinventorydata["viewermail"]);
    
    console.log(viewerinfo,addinventorydata,macaddress);
    if(!viewerinfo){

      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "Viewer is not in your list add a viewer first";
      this.setState(snackbar);
      return;

    }

  

    addinventorydata["timestamp"] = Date.now();
    addinventorydata["totalweight"] =
      parseFloat(addinventorydata["itemqty"]) *
      parseFloat(addinventorydata["itemweight"]);
    addinventorydata["datatype"] = type ? type : "inlet";
    this.setState({ inventoryuploadloading: true });

    const database = firebase.database();
    database
      .ref("Device")
      .child(macaddress)
      .child("info")
      .child(addinventorydata["timestamp"])
      .set(addinventorydata)
      .then((e) => {
        this.setState({
          inventoryuploadloading: false,
          openinventorymodal: false,
          openexitinventorymodal: false,
        });
      })
      .catch((e) => {
        const { snackbar } = this.state;
        snackbar.open = true;
        snackbar.text = "unable to update data";
        this.setState(snackbar);
        this.setState({ inventoryuploadloading: false });
      });
  };

  inventorymodalhandleClose = () => {
    this.setState({ openinventorymodal: false, openexitinventorymodal: false });
  };

  vieweruploadsynchandleClick = () => {
    var {
      addviewerdata,
      macaddress,
      viewerinfo,
      devicename,
      isviewer,
      searchuserbymail,
      userslistforviewerpermission,
    } = this.state;

    var data: any = userslistforviewerpermission.find(
      (ea: any) => ea.mail == searchuserbymail
    );
    if (!data) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "No user found by this mail";
      this.setState(snackbar);
      return;
    }
    console.log(addviewerdata);

    if (!addviewerdata["viewertype"]) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "viewer type required";
      this.setState(snackbar);
      return;
    }
    if (!addviewerdata["warehousename"]) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "warehouse name required";
      this.setState(snackbar);
      return;
    }
    if (!addviewerdata["space"]) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "space required";
      this.setState(snackbar);
      return;
    }
    if (!addviewerdata["others"]) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "others required";
      this.setState(snackbar);
      return;
    }

    addviewerdata["uid"] = data.uid;
    addviewerdata["mail"] = data.mail;

    if (data.mail == this.state.profile.mail) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "You can't add yourself as viewer";
      this.setState(snackbar);
      return;
    }

    if (isviewer) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "Invalid access";
      this.setState(snackbar);
      return;
    }

    if (addviewerdata["mail"] && addviewerdata["mail"].length <= 0) {
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "Select a mail id to proceed";
      this.setState(snackbar);
      return;
    }

    if (
      !viewerinfo ||
      !Object.keys(viewerinfo).includes(addviewerdata["uid"])
    ) {
      this.setState({ vieweruploadloading: true });
      const database = firebase.database();
      database
        .ref("Device")
        .child(macaddress)
        .child("viewers")
        .child(addviewerdata["uid"])
        .set(addviewerdata)
        .then((e) => {
          database
            .ref("Users")
            .child(addviewerdata["uid"])
            .child("devices")
            .child(macaddress)
            .set(devicename)
            .then((e) => {
              
              this.setState({
                vieweruploadloading: false,
                openviewermodal: false,
              });
            })
            .catch((e) => {
              console.log(e);
              
              const { snackbar } = this.state;
              snackbar.open = true;
              snackbar.text = "unable to update data";
              this.setState(snackbar);
              this.setState({ vieweruploadloading: false });
            });
        })
        .catch((e) => {
          console.log(e);
          
          const { snackbar } = this.state;
          snackbar.open = true;
          snackbar.text = "unable to update data";
          this.setState(snackbar);
          this.setState({ vieweruploadloading: false });
        });
    } else {
      alert("Viewer already registered...");
      const { snackbar } = this.state;
      snackbar.open = true;
      snackbar.text = "viewer already registered...";
      this.setState(snackbar);
    }
  };

  viewermodalhandleClose = () => {
    this.setState({ openviewermodal: false });
  };

  setsidenavbarVisible = () => {
    const { visible } = this.state;
    this.setState({ visible: !visible });
  };

  handleItemClick = (selectedItem: string) => {
    // Handle item click logic here
    var { navbarclickcontrol,predata,profile } = this.state;
    console.log(`Selected item: ${selectedItem}`,profile);

    if(predata["pack"] == 10 && (profile && profile.isadmin==false)){
      alert("pack expired contact admin")
    
      return
    }

    if (selectedItem == "Info") {
      navbarclickcontrol = [true, false, false, false, false, false];
      this.setState({ navbarclickcontrol });
    } else if (selectedItem == "Inventory") {
      navbarclickcontrol = [false, true, false, false, false, false];
      this.setState({ navbarclickcontrol });
    } else if (selectedItem == "Monitor") {
      navbarclickcontrol = [false, false, true, false, false, false];
      this.setState({ navbarclickcontrol });
    } else if (selectedItem == "RealTime") {
      navbarclickcontrol = [false, false, false, true, false, false];
      this.setState({ navbarclickcontrol });
    } else if (selectedItem == "Control") {
      navbarclickcontrol = [false, false, false, false, true, false];
      this.setState({ navbarclickcontrol });
    } else if (selectedItem == "Viewers") {
      navbarclickcontrol = [false, false, false, false, false, true];
      this.setState({ navbarclickcontrol });
    }
  };

  handlesnackbarClose = () => {
    const { snackbar } = this.state;
    snackbar.open = false;
    this.setState(snackbar);
  };

  getRowClassName = (params: any) => {
    const age = params.row["datatype"];

    // Apply a class based on the value of the 'age' cell
    return age == "outlet" ? "outletview" : "inletview";
  };

  render() {
    const modalstyle = {
      position: "absolute" as "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      width: 400,
      bgcolor: "background.paper",
      border: "2px solid #000",
      boxShadow: 24,
      pt: 2,
      px: 4,
      pb: 3,
    };

    const {
      datasetdata,
      hasgraphdata,
      fromdate,
      todate,
      mindate,
      maxdate,
      isSinglegraphdisplay,
      firstdatemin,
      firstdatemax,
      moddalisopened,
      setpoints,
      macaddress,
      nographfound,
      filterdropdown,
      customopen,
      deviceinfo,
      devicename,
      tabsval,
      realtime,
      uploadloading,
      inventoryuploadloading,
      deviceimageurl,
      openinventorymodal,
      addinventorydata,
      visible,
      navbarclickcontrol,
      countinfo,
      openviewermodal,
      addviewerdata,
      viewerinfo,
      userslistforviewerpermission,
      vieweruploadloading,
      isviewer,
      snackbar,
      predata,
      warehousedata,
      warehousedataloading,
      datatableloading,
      openexitinventorymodal,
      currentnventerydata,
      searchuserbymail,
      relaystogglestate,
      profile
    } = this.state;

    return (
      <div>
        <Layout className={`layout-dashboard`}>
          <Drawer
            title={false}
            placement={"left"}
            closable={true}
            onClose={() => this.setsidenavbarVisible}
            visible={visible}
            key={"left"}
            width={250}
            className={`drawer-sidebar`}
          >
            <Layout className={`layout-dashboard`}>
              <Sider
                trigger={null}
                width={250}
                theme="light"
                className={`sider-primary ant-layout-sider-primary active-route`}
                style={{ background: "#fff" }}
              >
                <SideNavbar onItemClick={this.handleItemClick} />
              </Sider>
            </Layout>
          </Drawer>
          <Sider
            breakpoint="lg"
            collapsedWidth="0"
            onCollapse={(collapsed, type) => {
              console.log(collapsed, type);
            }}
            trigger={null}
            width={250}
            theme="light"
            className={`sider-primary ant-layout-sider-primary active-route`}
            style={{ background: "fff" }}
          >
            <SideNavbar onItemClick={this.handleItemClick} />
          </Sider>
        </Layout>

        <div
          style={{
            marginLeft: "270px",
            backgroundColor: "#d5d5dd",
            padding: "15px",
            minHeight: "550px",
            display: navbarclickcontrol[0] == true ? "block" : "none",
          }}
        >
          <Row className="rowgap-vbox" gutter={[24, 0]}>
            {countinfo.map((c: any, index: any) => (
              <Col
                key={index}
                xs={24}
                sm={24}
                md={12}
                lg={6}
                xl={6}
                className="mb-24"
              >
                <Card bordered={false} className="criclebox ">
                  <div className="number">
                    <Row align="middle" gutter={[24, 0]}>
                      <Col xs={18}>
                        <span>{c.today}</span>
                        <Typography>{c.title}</Typography>
                      </Col>
                      <Col xs={6}>
                        <div className="icon-box">{c.icon}</div>
                      </Col>
                    </Row>
                  </div>
                </Card>
              </Col>
            ))}
            
          </Row>

          <div>
            <div
              className="col-md-6"
              style={{
                float: "left",
                alignSelf: "center",
                marginLeft: "auto",
                marginRight: "auto",
              }}
            >
              {/* <div className="linechart">
                <div>
                  <h5>Active Users</h5>
                  <p className="lastweek">
                    than last week <span className="bnb2">+30%</span>
                  </p>
                </div>
                <div className="sales">
                  <ul>
                    <li>{<MinusOutlined />} Traffic</li>
                    <li>{<MinusOutlined />} Sales</li>
                  </ul>
                </div>
              </div>

              <ReactApexChart
                className="full-width"
                series={this.lineChart.series}
                options={{
                  chart: {
                    width: "100%",
                    height: 350,
                    toolbar: {
                      show: false,
                    },
                  },

                  legend: {
                    show: false,
                  },

                  dataLabels: {
                    enabled: false,
                  },
                  stroke: {
                    curve: "smooth",
                  },

                  yaxis: {
                    labels: {
                      style: {
                        fontSize: "14px",
                        fontWeight: 600,
                        colors: ["#8c8c8c"],
                      },
                    },
                  },

                  xaxis: {
                    labels: {
                      style: {
                        fontSize: "14px",
                        fontWeight: 600,
                        colors: [
                          "#8c8c8c",
                          "#8c8c8c",
                          "#8c8c8c",
                          "#8c8c8c",
                          "#8c8c8c",
                          "#8c8c8c",
                          "#8c8c8c",
                          "#8c8c8c",
                          "#8c8c8c",
                        ],
                      },
                    },
                    categories: [
                      "Feb",
                      "Mar",
                      "Apr",
                      "May",
                      "Jun",
                      "Jul",
                      "Aug",
                      "Sep",
                      "Oct",
                    ],
                  },

                  tooltip: {
                    y: {
                      formatter: function (val: any) {
                        return val;
                      },
                    },
                  },
                }}
                type="area"
                height={350}
                width={"100%"}
              /> */}

              <div>
                <Box
                  component="form"
                  style={{ width: "500px" }}
                  sx={{
                    "& .MuiTextField-root": { m: 0.5, width: "25ch" },
                  }}
                  noValidate
                  autoComplete="off"
                >
                  <TextField
                    disabled
                    id="outlined-required"
                    label="Device Id"
                    value={macaddress.replaceAll(":", "")}
                  />
                  <TextField
                    disabled
                    id="outlined-required"
                    label="Device Name"
                    value={devicename}
                  />

                  <div>
                    <TextField
                      required
                      id="outlined-required"
                      label="Warehouse Name"
                      value={warehousedata ? warehousedata["name"] : "--"}
                      onChange={(e) => {
                        const { warehousedata } = this.state;
                        warehousedata["name"] = e.target.value;
                        this.setState({ warehousedata });
                      }}
                    />
                    <TextField
                      id="outlined-disabled"
                      label="Warehouse Address"
                      value={warehousedata ? warehousedata["address"] : "--"}
                      onChange={(e) => {
                        const { warehousedata } = this.state;
                        warehousedata["address"] = e.target.value;
                        this.setState({ warehousedata });
                      }}
                    />
                    <TextField
                      id="outlined-password-input"
                      label="Warehouse location"
                      value={warehousedata ? warehousedata["loc"] : "--"}
                      onChange={(e) => {
                        const { warehousedata } = this.state;
                        warehousedata["loc"] = e.target.value;
                        this.setState({ warehousedata });
                      }}
                    />
                    <TextField
                      id="outlined-read-only-input"
                      label="Ideal Temperature"
                      value={
                        warehousedata ? warehousedata["idealdata"]["temp"] : "0"
                      }
                      onChange={(e) => {
                        const { warehousedata } = this.state;
                        warehousedata["idealdata"]["temp"] = e.target.value;
                        this.setState({ warehousedata });
                      }}
                    />
                    <TextField
                      id="outlined-number"
                      label="Ideal humidity"
                      value={
                        warehousedata
                          ? warehousedata["idealdata"]["humid"]
                          : "0"
                      }
                      onChange={(e) => {
                        const { warehousedata } = this.state;
                        warehousedata["idealdata"]["humid"] = e.target.value;
                        this.setState({ warehousedata });
                      }}
                    />
                    <TextField
                      id="outlined-search"
                      label="Ideal co2"
                      value={
                        warehousedata ? warehousedata["idealdata"]["gas"] : "0"
                      }
                      onChange={(e) => {
                        const { warehousedata } = this.state;
                        warehousedata["idealdata"]["gas"] = e.target.value;
                        this.setState({ warehousedata });
                      }}
                    />
                  </div>
                  <LoadingButton
                  disabled={predata["pack"] == 10 && (profile && profile.isadmin==false)?true:false}
                    loading={warehousedataloading}
                    loadingPosition="end"
                    endIcon={<SaveIcon />}
                    variant="outlined"
                    onClick={() => {
                      const { warehousedata } = this.state;

                      this.setState({ warehousedataloading: true });

                      const db = firebase.database();
                      const ref = db
                        .ref("Device")
                        .child(macaddress)
                        .child("warehousedata");
                      ref
                        .set(warehousedata)
                        .then((e) => {
                          this.setState({ warehousedataloading: false });
                        })
                        .catch((err) => {
                          alert("err");
                          this.setState({ warehousedataloading: false });
                        });
                    }}
                  >
                    {warehousedataloading ? "Saving" : "Save"}
                  </LoadingButton>
                </Box>
              </div>
            </div>

            <div
              className="col-md-6"
              style={{
                float: "right",
                alignSelf: "center",
                marginTop: "auto",
                marginBottom: "auto",
              }}
            >
              <div className="text-center">
                <img
                  className="mx-auto d-block"
                  width={"200px"}
                  height={"200px"}
                  src={deviceimageurl}
                  alt=""
                  onClick={() => {
                    // Create a file input element
                    const fileInput = document.createElement("input");

                    // Set the input type to file
                    fileInput.type = "file";

                    // Use the accept attribute to restrict file types to JPG and PNG
                    fileInput.accept = "image/jpeg, image/png";

                    // // Add the file input element to the DOM
                    // document.body.appendChild(fileInput);

                    fileInput.addEventListener("change", (e: any) => {
                      const newImage = e.target.files[0];
                      if (newImage) {
                        // setImage(newImage);

                        // Upload the new image to Firebase Storage
                        const storageRef = firebase.storage().ref();

                        const imageRef = storageRef.child(
                          "images/" + macaddress + ".jpg"
                        );

                        imageRef.put(newImage).then((e) => {
                          console.log("Image uploaded successfully.");

                          // Get the download URL for the uploaded image
                          imageRef.getDownloadURL().then((url) => {
                            console.log("Download URL:", url);

                            const database = firebase.database();
                            database
                              .ref("Device")
                              .child(macaddress)
                              .child("image")
                              .set(url)
                              .then(() => {
                                console.log("Image URL saved in the database.");

                                this.setState({ deviceimageurl: url });
                              })
                              .catch((error) => {
                                console.error("Error saving image URL:", error);
                              });
                          });
                        });
                      }
                    });

                    fileInput.click();
                  }}
                  style={{
                    minHeight: "200px",
                    minWidth: "200px",
                    cursor: "pointer",
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        <Snackbar
          anchorOrigin={{
            vertical: "top",
            horizontal: "center",
          }}
          open={snackbar.open}
          onClose={this.handlesnackbarClose}
          message={snackbar.text}
          key={"topcenter"}
        />

        <div
          id="inventory"
          style={{
            display: navbarclickcontrol[1] == true ? "block" : "none",
            marginLeft: "270px",
            minHeight: "550px",
          }}
        >
          <h2 style={{ textAlign: "center" }}>Device Inventory</h2>
          <div className="row" style={{ display: "flex" }}>
            <div className="col-md-6" style={{ float: "left" }}>
              <div
                className="scrollable-div"
                style={{
                  overflowY: "scroll",
                  width: String(window.innerWidth - 250) + "px",
                  height: "auto",
                }}
              >
                <div
                  style={{
                    display:
                      deviceinfo && Object.keys(deviceinfo).length > 0
                        ? "block"
                        : "none",
                  }}
                >
                  <DataGrid
                    rows={deviceinfo ? deviceinfo : []}
                    columns={[
                      {
                        field: "timestamp",
                        headerName: "Timestamp",
                        flex: 1,
                      },
                      {
                        field: "item",
                        headerName: "Goods/Item Name",
                        flex: 1,
                      },
                      {
                        field: "itemtype",
                        headerName: "Goods/Item Type",
                        flex: 1,
                      },
                      {
                        field: "itemqty",
                        headerName: "Goods/Item Qty",
                        flex: 1,
                      },
                      {
                        field: "itemweight",
                        headerName: "Goods/Item Weight",
                        flex: 1,
                      },
                      {
                        field: "totalweight",
                        headerName: "Total Weight",
                        flex: 1,
                      },
                      {
                        field: "description",
                        headerName: "description",
                        flex: 1,
                      },
                      {
                        field: "entrydate",
                        headerName: "start date",
                        flex: 1,
                      },
                      {
                        field: "exitdate",
                        headerName: "end date",
                        flex: 1,
                      },
                      {
                        field: "marketval",
                        headerName: "Market value",
                        flex: 1,
                      },
                    ]}
                    getRowId={(row) => row.id}
                    // pageSize={10}
                    // rowsPerPageOptions={[10]}
                    // disableSelectionOnClick
                    autoHeight={true}
                    // pagination
                    // paginationMode="client"
                    // onPageChange={onPageChange}
                    // page={currentPage}
                    getRowClassName={this.getRowClassName}
                    onCellClick={(e) => {
                      console.log(e.row.id, deviceinfo[e.row.id - 1]);

                      this.setState({
                        currentnventerydata: JSON.parse(
                          JSON.stringify(deviceinfo)
                        )[e.row.id - 1],
                        openexitinventorymodal: true,
                        addinventorydata: deviceinfo[e.row.id - 1],
                      });
                    }}
                    loading={datatableloading}
                    components={{
                      NoRowsOverlay: () => (
                        <Stack
                          height="100%"
                          alignItems="center"
                          justifyContent="center"
                        >
                          <Typography>No inventory</Typography>
                        </Stack>
                      ),
                      NoResultsOverlay: () => (
                        <Stack
                          height="100%"
                          alignItems="center"
                          justifyContent="center"
                        >
                          <Typography>No Results</Typography>
                        </Stack>
                      ),
                      Toolbar: () => {
                        return (
                          <GridToolbarContainer>
                            <GridToolbarExport />
                          </GridToolbarContainer>
                        );
                      },
                    }}
                  />
                </div>

                <div
                  style={{
                    display:
                      deviceinfo != null && Object.keys(deviceinfo).length > 0
                        ? "none"
                        : "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    border: "1px solid #ccc",
                    marginLeft: "5px",
                    height: "90%",
                  }}
                >
                  <h3>No Inventory info found </h3>
                </div>
              </div>
            </div>
          </div>

          <Button
            style={{
              float: "left",
              padding: "8px",
              fontSize: "16px",
              marginTop: "8px",
              display: isviewer ? "none" : "block",
            }}
            type="button"
            onClick={() => {
              this.setState({
                openinventorymodal: true,
                addinventorydata: {
                  item: "",
                  itemtype: "",
                  itemqty: "0",
                  itemweight: "0",
                  totalweight: "0",
                  description: "",
                  entrydate: "",
                  exitdate: "",
                  marketval: "",
                  timestamp: "",
                },
              });
            }}
          >
            Add entry Inventory
          </Button>
        </div>

        <div
          id="monitor"
          style={{
            display: navbarclickcontrol[2] == true ? "block" : "none",
            marginLeft: "270px",
            minHeight: "550px",
          }}
        >
          <div
            style={{
              display: !hasgraphdata ? "block" : "none",
              textAlign: "center",
            }}
          >
            <Lottie
              loop
              animationData={
                nographfound == "init" ? animationData : nographdata
              }
              play
              style={{
                width: 500,
                height: 500,
                marginLeft: "auto",
                marginRight: "auto",
                display: "block",
              }}
            />
            <h4>
              {nographfound == "init"
                ? "Fetching data..."
                : "No graphical data found ...."}
            </h4>
          </div>

          <div
            id="monitoring"
            style={{ display: tabsval == 0 ? "block" : "none" }}
          >
            <div className="row" style={{ padding: "10px" }}>
              <Box
                style={{ float: "left" }}
                sx={{ minWidth: 50, maxWidth: 175 }}
              >
                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">
                    Select filter
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={filterdropdown}
                    label="Age"
                    onChange={this.handleChange}
                  >
                    <MenuItem selected value={0}>
                      Select filter
                    </MenuItem>
                    <MenuItem value={1}>1 hour</MenuItem>
                    <MenuItem value={2}>3 hours</MenuItem>
                    <MenuItem value={3}>24 hours</MenuItem>
                    <MenuItem value={4}>1 week</MenuItem>
                    <MenuItem value={5}>3 week</MenuItem>
                    <MenuItem value={6}>custom</MenuItem>
                  </Select>
                </FormControl>
              </Box>

              <div style={{ display: customopen ? "block" : "none" }}>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    float: "left",
                  }}
                >
                  <input
                    style={{
                      padding: "8px",
                      fontSize: "16px",
                      border: "1px solid #ccc",
                      borderRadius: "4px",
                      marginTop: "8px",
                    }}
                    type="date"
                    min={firstdatemin}
                    max={firstdatemax}
                    value={fromdate}
                    onChange={this.handleFromDateChange}
                  />
                </div>

                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    float: "left",
                  }}
                >
                  <input
                    style={{
                      padding: "8px",
                      fontSize: "16px",
                      border: "1px solid #ccc",
                      borderRadius: "4px",
                      marginTop: "8px",
                    }}
                    type="date"
                    max={maxdate}
                    min={mindate}
                    value={todate}
                    onChange={this.handletoDateChange}
                  />
                </div>

                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    float: "left",
                  }}
                >
                  <Button
                    style={{
                      float: "left",
                      padding: "8px",
                      fontSize: "16px",
                      marginTop: "8px",
                    }}
                    onClick={this.handlefilterclick}
                  >
                    filter
                  </Button>
                </div>
              </div>

              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  float: "right",
                }}
              >
                <Button
                  style={{
                    float: "left",
                    padding: "8px",
                    fontSize: "16px",
                    marginTop: "8px",
                  }}
                  onClick={this.handlefilterresetclick}
                >
                  reset
                </Button>
              </div>

              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  float: "left",
                }}
              >
                <FormGroup
                  style={{
                    float: "left",
                    padding: "8px",
                    border: "1px solid #ccc",
                    borderRadius: "4px",
                    fontSize: "16px",
                    marginTop: "8px",
                  }}
                >
                  <FormControlLabel
                    control={
                      <IOSSwitch sx={{ m: 0.5 }} value={isSinglegraphdisplay} />
                    }
                    label={
                      !isSinglegraphdisplay ? "Single graph" : "Multi graph"
                    }
                    onChange={() => {
                      this.setState({
                        isSinglegraphdisplay: !isSinglegraphdisplay,
                      });
                    }}
                  />
                </FormGroup>
              </div>
            </div>

            <div style={{ display: isSinglegraphdisplay ? "block" : "none" }}>
              <Button
                onClick={(e: any) => {
                  const but = e.target;
                  but.style.display = "none";
                  let input: any = window.document.querySelectorAll(".div2pdf");
                  const pdf = new pdfConverter("l", "px");

                  const promises: any = Array.from(input).map(
                    (canvasRef: any) => {
                      return html2canvas(canvasRef).then((canvas) => {
                        // Add each canvas as a new page to the PDF

                        const imgData = canvas.toDataURL("image/png");
                        pdf.addImage(
                          imgData,
                          "png",
                          0,
                          0,
                          canvasRef.clientWidth * 0.7,
                          canvasRef.clientHeight * 0.7
                        );
                        pdf.addPage();
                      });
                    }
                  );

                  // Wait for all promises to resolve before saving the PDF
                  Promise.all(promises).then(() => {
                    pdf.save("chart.pdf");
                    but.style.display = "block";
                  });
                }}
              >
                Export multi Graph
              </Button>

              <div className="multidiv2PDF">
                <div className="row">
                  <div
                    className="col-md-6 offset-md-3 text-center"
                    style={{ minWidth: "600px" }}
                  >
                    <Line
                      className="div2pdf"
                      options={{
                        responsive: true,
                        plugins: {
                          legend: {
                            position: "top" as const,
                          },
                          title: {
                            display: true,
                            text: "Chart.js Line Chart",
                          },
                        },
                      }}
                      data={{
                        labels: datasetdata.labels,
                        datasets: [
                          {
                            label: "Temperature",
                            data: datasetdata.dataset[0].data,
                            borderWidth: 1,
                            borderColor: "rgb(255, 99, 132)",
                            backgroundColor: "rgba(255, 99, 132, 0.5)",
                          },
                        ],
                      }}
                    />
                  </div>

                  <div
                    className="col-md-6 offset-md-3 text-center"
                    style={{ minWidth: "600px" }}
                  >
                    <Line
                      className="col-md-6 div2pdf"
                      options={{
                        responsive: true,
                        plugins: {
                          legend: {
                            position: "top" as const,
                          },
                          title: {
                            display: true,
                            text: "Chart.js Line Chart",
                          },
                        },
                      }}
                      data={{
                        labels: datasetdata.labels,
                        datasets: [
                          {
                            label: "Humidity",
                            data: datasetdata.dataset[1].data,
                            borderWidth: 1,
                            borderColor: "rgb(53, 162, 235)",
                            backgroundColor: "rgba(53, 162, 235, 0.5)",
                          },
                        ],
                      }}
                    />
                  </div>
                </div>

                <div className="row">
                  <div
                    className="col-md-6 offset-md-3 text-center div2pdf"
                    style={{ minWidth: "600px" }}
                  >
                    <Line
                      options={{
                        responsive: true,
                        plugins: {
                          legend: {
                            position: "top" as const,
                          },
                          title: {
                            display: true,
                            text: "Chart.js Line Chart",
                          },
                        },
                      }}
                      data={{
                        labels: datasetdata.labels,
                        datasets: [
                          {
                            label: "ppm",
                            data: datasetdata.dataset[2].data,
                            borderWidth: 1,
                            borderColor: "rgb(53, 162, 235)",
                            backgroundColor: "rgba(17, 245, 17, 0.5)",
                          },
                        ],
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div style={{ display: !isSinglegraphdisplay ? "block" : "none" }}>
              <Button
                onClick={(e: any) => {
                  const but = e.target;
                  but.style.display = "none";
                  let input: any =
                    window.document.getElementsByClassName("div2PDF")[0];

                  html2canvas(input).then((canvas: any) => {
                    const img = canvas.toDataURL("image/png");
                    const pdf = new pdfConverter("l", "px");
                    pdf.addImage(
                      img,
                      "png",
                      0,
                      0,
                      input.clientWidth * 0.7,
                      input.clientHeight * 0.7
                    );
                    pdf.save("chart.pdf");
                    but.style.display = "block";
                  });
                }}
              >
                Export Graph
              </Button>

              <Line
                className="div2PDF"
                options={{
                  responsive: true,
                  plugins: {
                    legend: {
                      position: "top" as const,
                    },
                    title: {
                      display: true,
                      text: "Chart.js Line Chart",
                    },
                  },
                }}
                data={{
                  labels: datasetdata.labels,
                  datasets: datasetdata.dataset,
                }}
              />
            </div>
          </div>
        </div>

        <div
          id="realtime"
          style={{
            display: navbarclickcontrol[3] == true ? "block" : "none",
            marginLeft: "270px",
            minHeight: "550px",
          }}
        >
          <div
            id="realtime"
            style={{
              width: "100%",
            }}
          >
            {/* <Bar
              options={{
                responsive: true,
                plugins: {
                  legend: {
                    position: "top" as const,
                  },
                  title: {
                    display: true,
                    text: "Chart.js Bar Chart",
                  },
                },
              }}
              style={{
                maxWidth: "500px",
                maxHeight: "500px",
                marginLeft: "auto",
                marginRight: "auto",
                minHeight: "500px",
                minWidth: "500px",
              }}
              data={realtime}
            /> */}

            <div
              style={{
                maxWidth: "500px",
                marginLeft: "auto",
                marginRight: "auto",
                minHeight: "500px",
                minWidth: "500px",
                marginTop: "50px",
              }}
            >
              <h3
                style={{
                  marginLeft: "auto",
                  marginRight: "auto",
                  textAlign: "center",
                }}
              >
                Realtime sensor data
              </h3>

              <Row gutter={16}>
                <Col span={8}>
                  <Card
                    bordered={false}
                    cover={
                      <img
                        alt="example"
                        style={{
                          height: "50px",
                          width: "50px",
                          marginLeft: "auto",
                          marginRight: "auto",
                        }}
                        src="https://img.icons8.com/fluency/48/thermometer-automation.png"
                      />
                    }
                  >
                    <Meta
                      style={{ whiteSpace: "normal" }}
                      title="Temperature"
                      description={realtime.datasets[0].data[0] + " C"}
                    />
                  </Card>
                </Col>
                <Col span={8}>
                  <Card
                    bordered={false}
                    cover={
                      <img
                        alt="example"
                        style={{
                          height: "50px",
                          width: "50px",
                          marginLeft: "auto",
                          marginRight: "auto",
                        }}
                        src="https://img.icons8.com/fluency/48/humidity.png"
                      />
                    }
                  >
                    <Meta
                      style={{ whiteSpace: "normal" }}
                      title="Humidity"
                      description={realtime.datasets[0].data[1] + " %"}
                    />
                  </Card>
                </Col>
                <Col span={8}>
                  <Card
                    bordered={false}
                    cover={
                      <img
                        alt="example"
                        style={{
                          height: "50px",
                          width: "50px",
                          marginLeft: "auto",
                          marginRight: "auto",
                        }}
                        src="https://img.icons8.com/fluency/48/co2.png"
                      />
                    }
                  >
                    <Meta
                      style={{ whiteSpace: "normal" }}
                      title="ppm"
                      description={realtime.datasets[0].data[2]}
                    />
                  </Card>
                </Col>
              </Row>
              <h3
                style={{
                  marginLeft: "auto",
                  marginRight: "auto",
                  textAlign: "center",
                }}
              >
                Realtime LDR data
              </h3>

              <Row style={{ marginTop: "10px" }} gutter={16}>
                <Col span={8}>
                  <Card
                    bordered={false}
                    cover={
                      <img
                        alt="example"
                        style={{
                          height: "50px",
                          width: "50px",
                          marginLeft: "auto",
                          marginRight: "auto",
                        }}
                        src={
                          realtime.datasets[0].data[3] &&
                          realtime.datasets[0].data[3] == 0
                            ? "https://img.icons8.com/fluency/48/000000/led-diode.png"
                            : "https://img.icons8.com/fluency/48/led-diode.png"
                        }
                      />
                    }
                  >
                    <Meta
                      style={{ whiteSpace: "normal" }}
                      title="LDR 1"
                      description={String(realtime.datasets[0].data[3])}
                    />
                  </Card>
                </Col>
                <Col span={8}>
                  <Card
                    bordered={false}
                    cover={
                      <img
                        alt="example"
                        style={{
                          height: "50px",
                          width: "50px",
                          marginLeft: "auto",
                          marginRight: "auto",
                        }}
                        src={
                          realtime.datasets[0].data[4] &&
                          realtime.datasets[0].data[4] == 1
                            ? "https://img.icons8.com/fluency/48/000000/led-diode.png"
                            : "https://img.icons8.com/fluency/48/led-diode.png"
                        }
                      />
                    }
                  >
                    <Meta
                      style={{ whiteSpace: "normal" }}
                      title="LDR 2"
                      description={String(realtime.datasets[0].data[4])}
                    />
                  </Card>
                </Col>
                <Col span={8}>
                  <Card
                    bordered={false}
                    cover={
                      <img
                        alt="example"
                        style={{
                          height: "50px",
                          width: "50px",
                          marginLeft: "auto",
                          marginRight: "auto",
                        }}
                        src={
                          realtime.datasets[0].data[5] &&
                          realtime.datasets[0].data[5] == 1
                            ? "https://img.icons8.com/fluency/48/000000/led-diode.png"
                            : "https://img.icons8.com/fluency/48/led-diode.png"
                        }
                      />
                    }
                  >
                    <Meta
                      style={{ whiteSpace: "normal" }}
                      title="LDR 3"
                      description={String(realtime.datasets[0].data[5])}
                    />
                  </Card>
                </Col>
              </Row>

              <Row style={{ marginTop: "10px" }} gutter={16}>
                <Col span={8}>
                  <Card
                    bordered={false}
                    cover={
                      <img
                        alt="example"
                        style={{
                          height: "50px",
                          width: "50px",
                          marginLeft: "auto",
                          marginRight: "auto",
                        }}
                        src={
                          String(realtime.datasets[0].data[6]) == "1"
                            ? "https://img.icons8.com/fluency/96/000000/led-diode.png"
                            : "https://img.icons8.com/fluency/48/led-diode.png"
                        }
                      />
                    }
                  >
                    <Meta
                      style={{ whiteSpace: "normal" }}
                      title="LDR 4"
                      description={String(realtime.datasets[0].data[6])}
                    />
                  </Card>
                </Col>
              </Row>




              <h3
                style={{
                  marginLeft: "auto",
                  marginRight: "auto",
                  textAlign: "center",
                }}
              >
                Realtime Relay toggle status
              </h3>

              <Row style={{ marginTop: "10px" }} gutter={16}>
                <Col span={8}>
                  <Card
                    bordered={false}
                  
                  >
                    <Meta
                      style={{ whiteSpace: "normal" }}
                      title="RELAY 1"
                      description={String(relaystogglestate.length>0 &&
                        relaystogglestate[0] == 0?"OFF":"ON")}
                    />
                  </Card>
                </Col>
                <Col span={8}>
                  <Card
                    bordered={false}
                  
                  >
                    <Meta
                      style={{ whiteSpace: "normal" }}
                      title="RELAY 2"
                      description={String(relaystogglestate.length>1 &&
                        relaystogglestate[1] == 0?"OFF":"ON")}
                    />
                  </Card>
                </Col>
                <Col span={8}>
                  <Card
                    bordered={false}
                    
                  >
                    <Meta
                      style={{ whiteSpace: "normal" }}
                      title="RELAY 3"
                      description={String(relaystogglestate.length>2 &&
                        relaystogglestate[2] == 0?"OFF":"ON")}
                    />
                  </Card>
                </Col>
              </Row>

              <Row style={{ marginTop: "10px" }} gutter={16}>
                <Col span={8}>
                  <Card
                    bordered={false}
                    
                  >
                    <Meta
                      style={{ whiteSpace: "normal" }}
                      title="RELAY 4"
                      description={String(relaystogglestate.length>3 &&
                        relaystogglestate[3] == 0?"OFF":"ON")}
                    />
                  </Card>
                </Col>
                <Col span={8}>
                  <Card
                    bordered={false}
                    
                  >
                    <Meta
                      style={{ whiteSpace: "normal" }}
                      title="RELAY 5"
                      description={String(relaystogglestate.length>4 &&
                        relaystogglestate[4] == 0?"OFF":"ON")}
                    />
                  </Card>
                </Col>
                <Col span={8}>
                  <Card
                    bordered={false}
                    
                  >
                    <Meta
                      style={{ whiteSpace: "normal" }}
                      title="RELAY 6"
                      description={String(relaystogglestate.length>5 &&
                        relaystogglestate[5] == 0?"OFF":"ON")}
                    />
                  </Card>
                </Col>
              </Row>




              <h3
                style={{
                  marginLeft: "auto",
                  marginRight: "auto",
                  textAlign: "center",
                }}
              >
                Last updated at : {String(realtime.datasets[0].data[7])}
              </h3>

              <h3
                style={{
                  marginLeft: "auto",
                  marginRight: "auto",
                  textAlign: "center",
                }}
              >
                Data Sync Interval :{" "}
                {String(setpoints["interval"]) + " minutes"}
              </h3>
            </div>
          </div>
        </div>

        <div
          id="control"
          style={{
            display: navbarclickcontrol[4] == true ? "block" : "none",
            marginLeft: "270px",
            minHeight: "550px",
          }}
        >
          <div id="control">
            <Box
              sx={{ width: 500 }}
              style={{
                marginRight: "auto",
                marginLeft: "auto",
                backgroundColor: "#e2e2e2",
              }}
            >
              {/* <Avatar alt="Remy Sharp" src={setpoints} /> */}
              <h2 id="parent-modal-title">Setpoints</h2>
              <Box
                component="form"
                sx={{
                  "& .MuiTextField-root": { m: 1, width: "25ch" },
                }}
                noValidate
                autoComplete="off"
              >
                <Card>
                  <Stack direction="row" spacing={1} alignItems="center">
                    <h5>Temperature</h5>
                    <Typography>Sync OFF</Typography>
                    <Switch
                      value={
                        setpoints["tempstate"] ? setpoints["tempstate"] : true
                      }
                      defaultChecked
                      onChange={(e) => {
                        setpoints["tempstate"] = !setpoints["tempstate"];
                        console.log(setpoints["tempstate"]);
                      }}
                    />
                    <Typography>Sync ON</Typography>
                  </Stack>

                  <div style={{ display: "flex", alignItems: "center" }}>
                    <Avatar
                      alt="Remy Sharp"
                      src="https://img.icons8.com/fluency/48/thermometer-down.png"
                    />
                    <TextField
                      required
                      disabled={isviewer ? true : false}
                      id="outlined-required"
                      label="min Temperature"
                      color="error"
                      value={setpoints["MinTemp"] ? setpoints["MinTemp"] : 0}
                      onChange={(e: any) => {
                        var val = e.target.value;

                        setpoints["MinTemp"] = parseInt(val);
                        this.setState({ setpoints });
                      }}
                    />

                    <Avatar
                      alt="Remy Sharp"
                      src="https://img.icons8.com/fluency/48/thermometer-up.png"
                    />

                    <TextField
                      required
                      color="error"
                      id="outlined-required"
                      label="max Temperature"
                      disabled={isviewer ? true : false}
                      value={setpoints["MaxTemp"] ? setpoints["MaxTemp"] : 0}
                      onChange={(e: any) => {
                        var val = e.target.value;

                        setpoints["MaxTemp"] = parseInt(val);
                        this.setState({ setpoints });
                      }}
                    />
                  </div>
                </Card>

                <Card style={{ marginTop: "5px", marginBottom: "2px" }}>
                  <Stack direction="row" spacing={1} alignItems="center">
                    <h5>Humidity</h5>
                    <Typography>Sync OFF</Typography>
                    <Switch
                      value={
                        setpoints["humidstate"] ? setpoints["humidstate"] : true
                      }
                      defaultChecked
                      onChange={(e) => {
                        setpoints["humidstate"] = !setpoints["humidstate"];
                        console.log(setpoints["humidstate"]);
                      }}
                    />
                    <Typography>Sync ON</Typography>
                  </Stack>

                  <div style={{ display: "flex", alignItems: "center" }}>
                    <Avatar
                      alt="Remy Sharp"
                      src="https://img.icons8.com/fluency/48/000000/hygrometer.png"
                    />

                    <TextField
                      required
                      id="outlined-required"
                      label="min Humidity"
                      disabled={isviewer ? true : false}
                      color="info"
                      value={setpoints["Minhum"] ? setpoints["Minhum"] : 0}
                      onChange={(e: any) => {
                        var val = e.target.value;

                        setpoints["Minhum"] = parseInt(val);
                        this.setState({ setpoints });
                      }}
                    />

                    <Avatar alt="Remy Sharp" src={highhum} />

                    <TextField
                      required
                      id="outlined-required"
                      label="max Humidity"
                      disabled={isviewer ? true : false}
                      color="info"
                      value={setpoints["Maxhum"] ? setpoints["Maxhum"] : 0}
                      onChange={(e: any) => {
                        var val = e.target.value;

                        setpoints["Maxhum"] = parseInt(val);
                        this.setState({ setpoints });
                      }}
                    />
                  </div>
                </Card>

                <Card>
                  <Stack direction="row" spacing={1} alignItems="center">
                    <h5>Co2</h5>
                    <Typography>Sync OFF</Typography>
                    <Switch
                      value={
                        setpoints["ppmstate"] ? setpoints["ppmstate"] : true
                      }
                      defaultChecked
                      onChange={(e) => {
                        setpoints["ppmstate"] = !setpoints["ppmstate"];
                        console.log(setpoints["ppmstate"]);
                      }}
                    />
                    <Typography>Sync ON</Typography>
                  </Stack>
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <Avatar alt="Remy Sharp" src={lowco2} />

                    <TextField
                      required
                      id="outlined-required"
                      label="min Co2"
                      color="success"
                      disabled={isviewer ? true : false}
                      value={setpoints["MinPPM"] ? setpoints["MinPPM"] : 0}
                      onChange={(e: any) => {
                        var val = e.target.value;

                        setpoints["MinPPM"] = parseInt(val);
                        this.setState({ setpoints });
                      }}
                    />

                    <Avatar alt="Remy Sharp" src={highco2} />

                    <TextField
                      required
                      id="outlined-required"
                      color="success"
                      label="max Co2"
                      disabled={isviewer ? true : false}
                      value={setpoints["MaxPPM"] ? setpoints["MaxPPM"] : 0}
                      onChange={(e: any) => {
                        var val = e.target.value;

                        setpoints["MaxPPM"] = parseInt(val);
                        this.setState({ setpoints });
                      }}
                    />
                  </div>
                </Card>

                <Card>
                  <h5>Set Time Interval</h5>

                  <Stack direction="row" spacing={1} alignItems="center">
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        width: "100vh",
                      }}
                    >
                      <Avatar
                        alt="Remy Sharp"
                        src="https://img.icons8.com/cute-clipart/64/property-with-timer.png"
                      />

                      <Slider
                        disabled={isviewer ? true : false}
                        style={{ marginLeft: "15px", marginRight: "15px" }}
                        aria-label="Set interval"
                        value={
                          setpoints["interval"] ? setpoints["interval"] : 0
                        }
                        step={this.markings.length}
                        valueLabelDisplay="on"
                        color="secondary"
                        marks={this.markings}
                        onChange={(e: any) => {
                          setpoints["interval"] = parseInt(e.target.value);
                          console.log(setpoints["interval"]);

                          this.setState({
                            intervalvaluetext: e.target.value,
                            setpoints,
                          });
                        }}
                      />
                    </div>

                    <div>
                      <OutlinedInput
                        id="outlined-basic"
                        value={
                          setpoints["interval"] ? setpoints["interval"] : 0
                        }
                        endAdornment={
                          <InputAdornment position="end">min</InputAdornment>
                        }
                        onChange={(e) => {
                          setpoints["interval"] = e.target.value;

                          this.setState(setpoints);
                        }}
                        label="Time interval"
                      />
                    </div>
                  </Stack>
                </Card>

                <div
                  style={{
                    width: "100%",
                    display: "flex",
                    alignItems: "center",
                    margin: "10px",
                    padding: "5px",
                  }}
                >
                  <LoadingButton
                    disabled={isviewer ? true : false}
                    style={{ marginLeft: "auto", marginRight: "auto" }}
                    size="small"
                    onClick={this.uploadsynchandleClick}
                    endIcon={<CloudSync />}
                    loading={uploadloading}
                    loadingPosition="end"
                    variant="contained"
                  >
                    <span>Send</span>
                  </LoadingButton>
                </div>
              </Box>
            </Box>
          </div>
        </div>

        <div
          id="viewers"
          style={{
            display: navbarclickcontrol[5] == true ? "block" : "none",
            marginLeft: "270px",
            minHeight: "550px",
          }}
        >
          <div className="card-header">
            <h2 style={{ textAlign: "center" }}>Device Viewers</h2>
          </div>
          <div className="card-body">
            <div className="row" style={{ display: "flex" }}>
              <div className="col-md-6" style={{ float: "left" }}>
                <div
                  className="scrollable-div"
                  style={{
                    overflowY: "scroll",
                    minWidth: "650px",
                    width: String(window.innerWidth - 250) + "px",
                  }}
                >
                  <div
                    style={{
                      display: viewerinfo ? "block" : "none",
                    }}
                  >
                    <DataGrid
                      rows={viewerinfo ? viewerinfo : []}
                      columns={[
                        {
                          field: "mail",
                          headerName: "Viewer Mail",
                          flex: 1,
                        },
                        {
                          field: "viewertype",
                          headerName: "Viewer type",
                          flex: 1,
                        },
                        {
                          field: "warehousename",
                          headerName: "Warehouse Name",
                          flex: 1,
                        },
                        {
                          field: "space",
                          headerName: "Space Allocated",
                          flex: 1,
                        },
                        {
                          field: "others",
                          headerName: "Other Info",
                          flex: 1,
                        },
                      ]}
                      getRowId={(row) => row.id}
                      // pageSize={10}
                      // rowsPerPageOptions={[10]}
                      // disableSelectionOnClick
                      autoHeight={true}
                      // pagination
                      // paginationMode="client"
                      // onPageChange={onPageChange}
                      // page={currentPage}
                      // getRowClassName={this.getRowClassName}
                      onCellClick={(e) => {
                        console.log(e.row.id, viewerinfo[e.row.id - 1]);

                        this.setState({
                          currentnventerydata: JSON.parse(
                            JSON.stringify(viewerinfo)
                          )[e.row.id - 1],
                          openexitinventorymodal: true,
                          addinventorydata: viewerinfo[e.row.id - 1],
                        });
                      }}
                      loading={datatableloading}
                      components={{
                        NoRowsOverlay: () => (
                          <Stack
                            height="100%"
                            alignItems="center"
                            justifyContent="center"
                          >
                            <Typography>No inventory</Typography>
                          </Stack>
                        ),
                        NoResultsOverlay: () => (
                          <Stack
                            height="100%"
                            alignItems="center"
                            justifyContent="center"
                          >
                            <Typography>No Results</Typography>
                          </Stack>
                        ),
                        Toolbar: () => {
                          return (
                            <GridToolbarContainer>
                              <GridToolbarExport />
                            </GridToolbarContainer>
                          );
                        },
                      }}
                    />
                  </div>

                  <div
                    style={{
                      display: !viewerinfo ? "none" : "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      border: "1px solid #ccc",
                      marginLeft: "5px",
                      height: "90%",
                    }}
                  >
                    <h3>No viewer assigned yet</h3>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <Button
            disabled={isviewer ? true : false}
            style={{
              float: "left",
              padding: "8px",
              fontSize: "16px",
              marginTop: "8px",
            }}
            type="button"
            onClick={() => {
              this.setState({
                openviewermodal: true,
                // addviewerdata: {
                //   uid: "",
                //   mail: "",
                //   viewertype: "",
                //   warehousename: "",
                //   space: "",
                //   others: "",
                // },
              });
            }}
          >
            Add Viewer to this device
          </Button>
        </div>

        <Dialog
          open={openinventorymodal}
          TransitionComponent={Transition}
          keepMounted
          onClose={this.inventorymodalhandleClose}
          aria-describedby="alert-dialog-slide-description"
        >
          <DialogTitle>{"Add an Inventory !!!"}</DialogTitle>
          <DialogContent>
            <Box
              component="form"
              sx={{
                "& .MuiTextField-root": { m: 1, width: "25ch" },
              }}
              noValidate
              autoComplete="off"
            >
              <Card>
                <div style={{ display: "flex", alignItems: "center" }}>
                  <Avatar
                    alt="Remy Sharp"
                    src="https://img.icons8.com/fluency/48/company.png"
                  />
                  <TextField
                    required
                    id="outlined-required"
                    label="Goods/Item Name"
                    color="error"
                    value={addinventorydata["item"]}
                    onChange={(e: any) => {
                      var val = e.target.value;

                      addinventorydata["item"] = val;
                      this.setState({ addinventorydata });
                    }}
                  />

                  <Avatar
                    alt="Remy Sharp"
                    src="https://img.icons8.com/fluency/48/worker-male.png"
                  />

                  <TextField
                    required
                    color="error"
                    id="outlined-required"
                    label="Goods/Item type"
                    value={addinventorydata["itemtype"]}
                    onChange={(e: any) => {
                      var val = e.target.value;

                      addinventorydata["itemtype"] = val;
                      this.setState({ addinventorydata });
                    }}
                  />
                </div>
              </Card>

              <Card style={{ marginTop: "5px", marginBottom: "5px" }}>
                <div style={{ display: "flex", alignItems: "center" }}>
                  <Avatar
                    alt="Remy Sharp"
                    src="https://img.icons8.com/fluency/48/hamper.png"
                  />

                  <TextField
                    required
                    id="outlined-required"
                    label="Goods/Item quantity"
                    color="info"
                    value={addinventorydata["itemqty"]}
                    type="number"
                    onChange={(e: any) => {
                      var val = e.target.value;

                      addinventorydata["itemqty"] = val;
                      this.setState({ addinventorydata });
                    }}
                  />

                  <Avatar
                    alt="Remy Sharp"
                    src="https://img.icons8.com/fluency/48/counter.png"
                  />

                  <TextField
                    required
                    id="outlined-required"
                    label="Goods/Item weight"
                    color="info"
                    value={addinventorydata["itemweight"]}
                    type="number"
                    onChange={(e: any) => {
                      var val = e.target.value;

                      addinventorydata["itemweight"] = val;

                      this.setState({ addinventorydata });
                    }}
                  />
                </div>
                <h3>
                  Total weight of Goods/Items :{" "}
                  {parseFloat(addinventorydata["itemqty"]) *
                    parseFloat(addinventorydata["itemweight"])}
                </h3>
              </Card>

              <Card>
                <div style={{ display: "flex", alignItems: "center" }}>
                  <Avatar
                    alt="Remy Sharp"
                    src="https://img.icons8.com/fluency/48/date-to.png"
                  />

                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      float: "left",
                      marginLeft: "5px",
                    }}
                  >
                    <input
                      style={{
                        padding: "8px",
                        fontSize: "16px",
                        border: "1px solid #ccc",
                        borderRadius: "4px",
                        marginTop: "8px",
                      }}
                      type="date"
                      value={addinventorydata["entrydate"]}
                      onChange={(e: any) => {
                        var val = e.target.value;
                        addinventorydata["entrydate"] = val;
                        this.setState({ addinventorydata });
                      }}
                    />
                  </div>

                  <Avatar
                    style={{ marginLeft: "50px" }}
                    alt="Remy Sharp"
                    src="https://img.icons8.com/fluency/48/pay-date.png"
                  />

                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      float: "left",
                    }}
                  >
                    <input
                      style={{
                        padding: "8px",
                        fontSize: "16px",
                        border: "1px solid #ccc",
                        borderRadius: "4px",
                        marginTop: "8px",
                      }}
                      type="date"
                      value={addinventorydata["exitdate"]}
                      onChange={(e: any) => {
                        var val = e.target.value;

                        addinventorydata["exitdate"] = val;
                        this.setState({ addinventorydata });
                      }}
                    />
                  </div>
                </div>
              </Card>

              <Card style={{ marginTop: "5px", marginBottom: "5px" }}>
                <div style={{ display: "flex", alignItems: "center" }}>
                  <Avatar
                    alt="Remy Sharp"
                    src="https://img.icons8.com/fluency/48/hamper.png"
                  />

                  <TextField
                    required
                    id="outlined-required"
                    label="Goods/Item description"
                    color="info"
                    value={addinventorydata["description"]}
                    onChange={(e: any) => {
                      var val = e.target.value;

                      addinventorydata["description"] = val;
                      this.setState({ addinventorydata });
                    }}
                  />

                  <Avatar
                    alt="Remy Sharp"
                    src="https://img.icons8.com/fluency/48/counter.png"
                  />

                  <TextField
                    required
                    id="outlined-required"
                    label="Goods/Item marketval"
                    color="info"
                    value={addinventorydata["marketval"]}
                    onChange={(e: any) => {
                      var val = e.target.value;

                      addinventorydata["marketval"] = val;
                      this.setState({ addinventorydata });
                    }}
                  />
                </div>
              </Card>

              <Card style={{ marginTop: "5px", marginBottom: "5px" }}>
                <div style={{ display: "flex", alignItems: "center" }}>
                
                  <Avatar
                    alt="Remy Sharp"
                    src="https://img.icons8.com/fluency/48/counter.png"
                  />

                  <TextField
                    required
                    id="outlined-required"
                    label="Enter viewer email id"
                    color="info"
                    value={addinventorydata["viewermail"]}
                    onChange={(e: any) => {

                      var val = e.target.value;
                      addinventorydata["viewermail"] = val;

                      this.setState({ addinventorydata });
                    }}
                  />
                </div>
              </Card>

            </Box>
          </DialogContent>
          <DialogActions>
            <LoadingButton
              size="small"
              onClick={() => {
                this.inventoryuploadsynchandleClick(null);
              }}
              endIcon={<CloudSync />}
              loading={inventoryuploadloading}
              loadingPosition="end"
              variant="contained"
            >
              <span>Add</span>
            </LoadingButton>
            <Button onClick={this.inventorymodalhandleClose}>Close</Button>
          </DialogActions>
        </Dialog>
        {/* <Dialog
          open={openviewermodal}
          TransitionComponent={Transition}
          keepMounted
          onClose={this.viewermodalhandleClose}
          aria-describedby="alert-dialog-slide-description"
        >
          <DialogTitle>{"Add a viewer !!!"}</DialogTitle>
          <DialogContent>
            <Box
              component="form"
              sx={{
                "& .MuiTextField-root": { m: 1, width: "500px" },
              }}
              style={{ height: "500px", width: "500px" }}
              noValidate
              autoComplete="off"
            >
              <Autocomplete
                disablePortal
                id="combo-box-demo"
                disabled={
                  userslistforviewerpermission.length > 0 ? false : true
                }
                options={userslistforviewerpermission}
                sx={{ width: 500 }}
                renderInput={(params) => (
                  <TextField {...params} label="Search viewer by mail id" />
                )}
                onChange={(e: any, value: any) => {
                  if (value) {
                    // this.setState({
                    //   addviewerdata: { uid: value.uid, mail: value.mail },
                    // });
                  }
                }}
              />
            </Box>
          </DialogContent>
          <DialogActions>
            <LoadingButton
              size="small"
              onClick={this.vieweruploadsynchandleClick}
              endIcon={<CloudSync />}
              loading={vieweruploadloading}
              loadingPosition="end"
              variant="contained"
            >
              <span>Add viewer</span>
            </LoadingButton>
            <Button onClick={this.viewermodalhandleClose}>Close</Button>
          </DialogActions>
        </Dialog> */}

        <Dialog
          open={openexitinventorymodal}
          TransitionComponent={Transition}
          keepMounted
          onClose={this.inventorymodalhandleClose}
          aria-describedby="alert-dialog-slide-description"
        >
          <DialogTitle>{"Add exit to the Inventory !!!"}</DialogTitle>
          <DialogContent>
            <Box
              component="form"
              sx={{
                "& .MuiTextField-root": { m: 1, width: "25ch" },
              }}
              noValidate
              autoComplete="off"
            >
              <Card style={{ marginTop: "5px", marginBottom: "5px" }}>
                <div style={{ display: "flex", alignItems: "center" }}>
                  <Avatar
                    alt="Remy Sharp"
                    src="https://img.icons8.com/fluency/48/hamper.png"
                  />

                  <TextField
                    required
                    id="outlined-required"
                    label="Goods/Item quantity"
                    color="info"
                    type="number"
                    onChange={(e: any) => {
                      var data = JSON.parse(
                        JSON.stringify(currentnventerydata)
                      );
                      var numval = parseInt(data["itemqty"]);

                      var val = parseInt(e.target.value);
                      if (e.target.value && val <= numval && val > 0) {
                        addinventorydata["itemqty"] = numval - val;
                      } else {
                        addinventorydata["itemqty"] = numval;
                      }

                      this.setState({ addinventorydata });
                    }}
                  />

                  <Avatar
                    alt="Remy Sharp"
                    src="https://img.icons8.com/fluency/48/counter.png"
                  />

                  <TextField
                    required
                    id="outlined-required"
                    label="Goods/Item weight"
                    color="info"
                    type="number"
                    onChange={(e: any) => {
                      var data = JSON.parse(
                        JSON.stringify(currentnventerydata)
                      );
                      var numval = parseInt(data["itemweight"]);

                      var val = parseInt(e.target.value);
                      if (e.target.value && val <= numval && val > 0) {
                        addinventorydata["itemweight"] = numval - val;
                      } else {
                        addinventorydata["itemweight"] = numval;
                      }

                      this.setState({ addinventorydata });
                    }}
                  />
                </div>
                <h3>
                  Available Goods/Items quantity :{" "}
                  {parseFloat(addinventorydata["itemqty"])}
                </h3>
                <h3>
                  Available Goods/Items weight :{" "}
                  {parseFloat(addinventorydata["itemweight"])}
                </h3>
                <h3>
                  Total weight of Goods/Items :{" "}
                  {parseFloat(addinventorydata["itemqty"]) *
                    parseFloat(addinventorydata["itemweight"])}
                </h3>
              </Card>
            </Box>
          </DialogContent>
          <DialogActions>
            <LoadingButton
              size="small"
              onClick={() => {
                this.inventoryuploadsynchandleClick("outlet");
              }}
              endIcon={<CloudSync />}
              loading={inventoryuploadloading}
              loadingPosition="end"
              variant="contained"
            >
              <span>update</span>
            </LoadingButton>
            <Button onClick={this.inventorymodalhandleClose}>Close</Button>
          </DialogActions>
        </Dialog>

        <Dialog
          open={openviewermodal}
          TransitionComponent={Transition}
          keepMounted
          onClose={this.viewermodalhandleClose}
          aria-describedby="alert-dialog-slide-description"
        >
          <DialogTitle>{"Add a viewer !!!"}</DialogTitle>
          <DialogContent>
            <Box
              component="form"
              sx={{
                "& .MuiTextField-root": { m: 1, width: "500px" },
              }}
              style={{ height: "500px", width: "500px" }}
              noValidate
              autoComplete="off"
            >
              <TextField
                id="outlined-basic"
                label="Search viewer by mail id"
                variant="outlined"
                disabled={
                  userslistforviewerpermission.length > 0 ? false : true
                }
                onChange={(e: any) => {
                  this.setState({ searchuserbymail: e.target.value });
                }}
              />

              <FormControl fullWidth>
                <InputLabel id="demo-simple-select-label">
                  viewer type
                </InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={10}
                  label="Age"
                  onChange={(e) => {
                    const { addviewerdata } = this.state;

                    console.log(e.target.value);
                    var dataval = e.target.value;
                    var viewertypee;
                    if (dataval == 10) {
                      viewertypee = "Farmer";
                    } else if (dataval == 20) {
                      viewertypee = "Government";
                    } else if (dataval == 30) {
                      viewertypee = "psu";
                    } else if (dataval == 40) {
                      viewertypee = "Fertilizer-company";
                    } else if (dataval == 50) {
                      viewertypee = "Firm";
                    }
                    addviewerdata["viewertype"] = viewertypee;
                    this.setState({ addviewerdata });
                  }}
                >
                  <MenuItem value={10}>Farmer</MenuItem>
                  <MenuItem value={20}>Government</MenuItem>
                  <MenuItem value={30}>psu</MenuItem>
                  <MenuItem value={40}>Fertilizer company</MenuItem>
                  <MenuItem value={50}>Firm</MenuItem>
                </Select>
              </FormControl>

              <TextField
                id="outlined-basic"
                label="Warehouse name"
                onChange={(el) => {
                  console.log(el.target.value);
                  var { addviewerdata } = this.state;
                  addviewerdata["warehousename"] = el.target.value;
                  this.setState({ addviewerdata });
                }}
                variant="outlined"
              />

              <TextField
                id="outlined-basic"
                label="Space Allocated"
                type="number"
                onChange={(el) => {
                  console.log(el.target.value);
                  var { addviewerdata } = this.state;
                  addviewerdata["space"] = el.target.value;
                  this.setState({ addviewerdata });
                }}
                variant="outlined"
              />

              <TextField
                id="outlined-basic"
                label="Other Information"
                onChange={(el) => {
                  console.log(el.target.value);
                  var { addviewerdata } = this.state;
                  addviewerdata["others"] = el.target.value;
                  this.setState({ addviewerdata });
                }}
                variant="outlined"
              />
            </Box>
          </DialogContent>
          <DialogActions>
            <LoadingButton
              size="small"
              onClick={this.vieweruploadsynchandleClick}
              endIcon={<CloudSync />}
              loading={vieweruploadloading}
              loadingPosition="end"
              variant="contained"
            >
              <span>Add viewer</span>
            </LoadingButton>
            <Button onClick={this.viewermodalhandleClose}>Close</Button>
          </DialogActions>
        </Dialog>

        <div
          style={{
            marginTop: "100px",
            marginLeft: "auto",
            marginRight: "auto",
            width: "fit-content",
          }}
        >
          <Typography variant="h6">Powered by</Typography>

          <img src={icon2} alt="logo" height={70} width={420} />
        </div>
      </div>
    );
  }
}

export default Devices;
