import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Tooltip,
  Avatar,
  MenuItem,
  Grid,
  styled,
  Paper,
  Card,
  CardContent,
  CardMedia,
  Badge,
} from "@mui/material";
import { Container, Box } from "@mui/system";
import React, { Component } from "react";
import { getCookie } from "../../controller/cookie.controller";
import firebase from "firebase";
import notfoundloading from "../../lotties/Animation - 1698317704788.json";
import initload from "../../lotties/initloading.json";
import Lottie from "react-lottie-player";
import { deepPurple } from "@mui/material/colors";
import { Layout, Drawer, Affix } from "antd";
import SideNavbar from "../../SideNavbar/SideNavbar";
import { NavLink } from "react-router-dom";

const { Header: AntHeader, Content, Sider } = Layout;

class Home extends Component {
  state: Readonly<{
    view: "login" | "loading";
    display: "normal" | "ask_for_installation";
    token: any;
    devicedata: any;
    hasdevices: string;
    devicestatus: any;
    visible: boolean;
    profile: any;
  }>;

  firebaseConfig = {
    apiKey: "AIzaSyALIxWc98nMBPC5opE4cG_o-4zF3epKwDQ",
    authDomain: "warebot-6957c.firebaseapp.com",
    databaseURL: "https://warebot-6957c-default-rtdb.firebaseio.com",
    projectId: "warebot-6957c",
    storageBucket: "warebot-6957c.appspot.com",
    messagingSenderId: "772347476312",
    appId: "1:772347476312:web:dd68b3449643fc8c16cd2d",
    measurementId: "G-HNR0VKT0PD",
  };

  constructor(props: any) {
    super(props);
    this.state = {
      view: "loading",
      display: "normal",
      token: null,
      devicedata: null,
      hasdevices: "init",
      devicestatus: {},
      visible: false,
      profile: null,
    };
  }

  componentDidMount(): void {
    var { devicedata, devicestatus, profile } = this.state;
    var token_: any = "";
    try {
      token_ = getCookie("__tkn__");
    } catch {
      window.location.replace("/login");
      return;
    }

    try {
      profile = getCookie("profile");

      profile = JSON.parse(profile);

      this.setState({ profile });
    } catch {
      window.location.replace("/login");
      return;
    }

    if (profile.isadmin) {
      window.location.href = "/admin";
    }

    if (!token_) {
      window.location.href = "/login";
    } else {
      console.log(token_, firebase.apps.length);
      this.setState({ token: token_ });
      firebase.apps.length <= 0
        ? firebase.initializeApp(this.firebaseConfig)
        : firebase.app();

      const database = firebase.database();
      const accountsRef = database.ref("Users").child(token_); // Replace 'accounts' with the actual path to your data in the database.
      const DeviceRef = database.ref("Device"); // Replace 'accounts' with the actual path to your data in the database.

      // Fetch account data
      accountsRef.child("devices").on("value", (snapshot) => {
        const accountData = snapshot.val();
        if (accountData) {
          // Function to parse timestamps and sort them in ascending order
          this.setState({ devicedata: accountData });

          Object.keys(accountData).map((item) => {
            console.log(item);
            devicestatus[item] = { status: 0 };
            DeviceRef.child(item).child("status").set(0);

            DeviceRef.child(item)
              .child("viewers")
              .on("value", (ress) => {
                var data = ress.val();
                console.log(data);

                if (data == null) {
                  return;
                }

                Object.keys(data).map((el) => {
                  if (el == profile.uid) {
                    devicestatus[item]["isviewer"] = true;
                    console.log(devicestatus);

                    this.setState({ devicestatus });
                  }
                });
              });

            DeviceRef.child(item)
              .child("status")
              .on("value", (snapshot1) => {
                const accountData1 = snapshot1.val();
                if (accountData1) {
                  console.log("Account data1:", item, accountData1);

                  devicestatus[item].status = parseInt(accountData1);
                  this.setState({ devicestatus });
                } else {
                  // this.setState({ hasdevices: "notfound" });
                }
              });

            DeviceRef.child(item)
              .child("image")
              .once("value", (snapshot1) => {
                const accountData1 = snapshot1.val();
                if (accountData1) {
                  console.log("image:", item, accountData1);

                  devicestatus[item].image = accountData1;
                  this.setState({ devicestatus });
                } else {
                  // this.setState({ hasdevices: "notfound" });
                }
              });
          });

          this.setState({ hasdevices: "gotdata" });
        } else {
          this.setState({ hasdevices: "notfound" });
        }
        console.log("Account data:", accountData);
      });
    }
  }
  setsidenavbarinVisible = () => {
    const { visible } = this.state;
    this.setState({ visible: false });
  };

  setsidenavbarVisible = () => {
    const { visible } = this.state;
    this.setState({ visible: true });
  };



  handleItemClick = (selectedItem: string) => {
    // Handle item click logic here
    console.log(`Selected item: ${selectedItem}`);
  };

  render() {
    const { devicedata, hasdevices, devicestatus, visible } = this.state;

    return (
      <div>
        <Layout className={`layout-dashboard`}>
          <Drawer
            title={false}
            placement={"left"}
            closable={true}
            onClose={this.setsidenavbarinVisible}
            open={visible}
            key={"left"}
            width={250}
            className={`drawer-sidebar`}>
            <Layout className={`layout-dashboard`}>
              <Sider
                trigger={null}
                width={250}
                theme="light"
                className={`sider-primary ant-layout-sider-primary active-route`}
                style={{ background: "#fff"}}
              >
                <SideNavbar onItemClick={this.handleItemClick} />
              </Sider>
            </Layout>
          </Drawer>
          <Sider
            breakpoint="lg"
            collapsedWidth="0"
            onCollapse={(collapsed, type) => {
              console.log(collapsed, type);
            }}
            trigger={null}
            width={250}
            theme="light"
            className={`sider-primary ant-layout-sider-primary active-route`}
            style={{ background: "fff", borderRight: "black 1px solid" ,margin:"0px"}}
          >
            <SideNavbar onItemClick={this.handleItemClick} />
          </Sider>
        </Layout>

         <NavLink to="">
              <span
                className="icon"
                style={{
                  background: "",
                  backgroundColor:"white",
                }}

                onClick={this.setsidenavbarVisible}
              >
                <img
                  src={
                    "https://img.icons8.com/fluency/48/circled-menu.png"
                  }
                />
              </span>
            </NavLink>

        <section style={{ marginLeft: "270px" }}>
          <Grid
            container
            spacing={1}
            style={{
              margin: "10px",
              width: "800px",
              display: hasdevices == "gotdata" ? "flex" : "none",
            }}
          >
            {hasdevices == "gotdata" &&
              Object.keys(devicedata).map((item) => (
                <Grid item xs={2.5} sm={2.5} md={2.5} lg={2.5}>
                  <Card
                    style={{
                      textAlign: "center",
                      width: "150px",
                      height: "150px",
                      cursor: "pointer",
                      boxShadow:"0 4px 6px rgb(0 0 0 / 12%)"
                    }}
                    data-extra={{ item }}
                    onClick={() => {
                      window.location.href = "/" + encodeURIComponent(item);
                    }}
                  >
                    <Badge
                      style={{ marginLeft: "100px", display: devicestatus[item].isviewer?"inline-flex":"none"}}
                      badgeContent={"viewer"}
                      color="primary"
                    ></Badge>
                    <div style={{ margin: "5px" }}>
                      <Box sx={{ flexGrow: 0 }}>
                        <Tooltip title={devicedata[item]}>
                          <IconButton sx={{ p: 0 }}>
                            <Avatar
                              alt="Remy Sharp"
                              src={
                                devicestatus[item].image
                                  ? devicestatus[item].image
                                  : "https://img.icons8.com/fluency/48/full-image.png"
                              }
                            />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    </div>
                    <CardContent>
                      <Typography variant="body2" style={{ cursor: "pointer" }}>
                        {devicedata[item]}
                      </Typography>
                      <h6
                        style={{
                          color:
                            devicestatus[item].status == 0 ? "red" : "green",
                          cursor: "pointer",
                        }}
                      >
                        {devicestatus[item].status == 0 ? "OFFLINE" : "ONLINE"}
                      </h6>
                    </CardContent>
                  </Card>
                </Grid>
              ))}
          </Grid>

          <div
            style={{
              margin: "10px",
              display: hasdevices !== "gotdata" ? "block" : "none",
              textAlign: "center",
            }}
          >
            <Lottie
              loop
              animationData={hasdevices == "init" ? initload : notfoundloading}
              play
              style={{
                width: 500,
                height: 500,
                marginLeft: "auto",
                marginRight: "auto",
              }}
            />
            <h2>
              {hasdevices == "init"
                ? "Getting info from cloud"
                : "No WareBOT linked to this account. Please use the WareBOT Mobile application to establish a connection or contact Warehouse to add you as a Viewer"}
            </h2>
          </div>
        </section>
      </div>
    );
  }
}

export default Home;
