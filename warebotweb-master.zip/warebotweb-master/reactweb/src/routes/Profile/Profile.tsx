import { Layout, Drawer } from "antd";
import Sider from "antd/es/layout/Sider";
import React, { Component } from "react";
import SideNavbar from "../../SideNavbar/SideNavbar";

export default class Profile extends Component {
  handleItemClick = (selectedItem: string) => {
    // Handle item click logic here
    console.log(`Selected item: ${selectedItem}`);
  };

  render() {
    return (
      <div>
        <Layout className={`layout-dashboard`}>
          <Drawer
            title={false}
            placement={"left"}
            closable={true}
            // onClose={() => this.setsidenavbarVisible}
            // visible={visible}
            key={"left"}
            width={250}
            className={`drawer-sidebar`}
          >
            <Layout className={`layout-dashboard`}>
              <Sider
                trigger={null}
                width={250}
                theme="light"
                className={`sider-primary ant-layout-sider-primary active-route`}
                style={{ background: "#fff" }}
              >
                <SideNavbar onItemClick={this.handleItemClick} />
              </Sider>
            </Layout>
          </Drawer>
          <Sider
            breakpoint="lg"
            collapsedWidth="0"
            onCollapse={(collapsed, type) => {
              console.log(collapsed, type);
            }}
            trigger={null}
            width={250}
            theme="light"
            className={`sider-primary ant-layout-sider-primary active-route`}
            style={{ background: "fff", borderRight: "black 1px solid" }}
          >
            <SideNavbar onItemClick={this.handleItemClick} />
          </Sider>
        </Layout>
      </div>
    );
  }
}
