import React, { Component } from 'react'
import {
  Stack,
  Card,
  Typography,
  Link,
  Button,
  LinearProgress,
} from "@mui/material";
import { storeCookie } from "../../controller/cookie.controller";

import MyIcon from "../../assets/logobot.gif";
import icon2 from "../../assets/logo.jpeg";

import GoogleButton from "react-google-button";
import { authenticateUser, continue_with_google } from '../../controller/google.controller';
import { Url } from '../../controller/url.controller';
import firebase from 'firebase';
import Cookies from 'js-cookie';

class Login extends Component {

  state: Readonly<{
    view: "login" | "loading";
    display: "normal" | "ask_for_installation";
    google: {
      btn: {
        disabled: boolean;
        text: string;
      };
    };

  }>;

  constructor(props: any) {
    super(props);
    this.state = {
      view: "loading",
      display: "normal",
      google: {
        btn: {
          disabled: false,
          text: "Sign in with Google",
        },
      }

    };
  }

  firebaseConfig = {
    apiKey: "AIzaSyALIxWc98nMBPC5opE4cG_o-4zF3epKwDQ",
    authDomain: "warebot-6957c.firebaseapp.com",
    databaseURL: "https://warebot-6957c-default-rtdb.firebaseio.com",
    projectId: "warebot-6957c",
    storageBucket: "warebot-6957c.appspot.com",
    messagingSenderId: "772347476312",
    appId: "1:772347476312:web:dd68b3449643fc8c16cd2d",
    measurementId: "G-HNR0VKT0PD"
  };


  componentDidMount(): void {

    var isDeploy = window.sessionStorage.getItem("deploy") || null;
    var url = new Url(window.location.href);
    console.log(url);

    if (url.isGoogleRedirect) {
      console.log("google redirect");
      var code = url.code as string;
      console.log(code);
      var google = this.state.google;
      google.btn.text = "Checking authorization...";
      google.btn.disabled = true;
      this.setState({ google, view: isDeploy ? "loading" : "login" });
      authenticateUser(code)
        .then((res) => {
          storeCookie("__tkn__", res);
          window.location.href = "/"
        })
        .catch((err) => {
          var google = this.state.google;
          google.btn.disabled = false;
          this.setState({ google, view: isDeploy ? "loading" : "login" });
          if (err === "invaild_grant") {
            alert("Invalid redirection, please re login again!");
            // continue_with_google();
          } else if (err === "invalid_scopes") {
            alert(
              "You are not authorized all the permissions! please select all the permissions!"
            );
            // continue_with_google();
          } else {
            console.log(err);
            // alert("Something went wrong, please re login again!");
            // continue_with_google();
          }
        });
    } else if (url.CreatorWantDeployAuth) {
      window.sessionStorage.setItem("deploy", url.CreatorWantDeployAuth);
      if (url.CreatorWantDeployAuth === "google") {
        this.setState({ deploy: "google" });
        continue_with_google();
      }
    } else {
      this.setState({ view: "login" });
    }
  }


  render() {
    var { view, google } = this.state;
    if (view === "login") {


      return (
        <>
          <Stack
            direction="column"
            justifyContent="center"
            alignItems="center"
            spacing={2}
            width={"100%"}
            height={"90dvh"}
          >
            <Stack>
              <Card sx={{ maxWidth: 650, width: 450 }} variant="outlined" style={{backgroundColor:"#e8e6e6"}}>
                <Stack
                  justifyContent="center"
                  alignItems="center"
                  sx={{ margin: "2.5rem" }}
                  spacing={2}
                >
                  <img src={MyIcon} alt="logo" height={70}width={650}/>
                 
                  <GoogleButton
                  style={{marginTop:"40px"}}
                    onClick={() => {
                      var google = this.state.google;
                      google.btn.disabled = true;
                      google.btn.text = "Signing in ......."
                      this.setState({ google });

                      firebase.apps.length <= 0 ? firebase.initializeApp(this.firebaseConfig) : firebase.app();


                      var auth = firebase.auth();
                      var provider = new firebase.auth.GoogleAuthProvider();
                      auth.signInWithPopup(provider).catch(alert).then((authe: any) => {


                        firebase.apps.length <= 0
                        ? firebase.initializeApp(this.firebaseConfig)
                        : firebase.app();
                
                      const database = firebase.database();
                      const accountsRef = database.ref("admins").child(authe.user.uid); // Replace 'accounts' with the actual path to your data in the database.
                      const UsersaccountsRef = database.ref("Users").child(authe.user.uid); // Replace 'accounts' with the actual path to your data in the database.
                      accountsRef.once("value",(eres)=>{

                        console.log(eres.val());
                        var isadmin = false;

                        if(eres.val()==null){
                          isadmin = false
                        }else{
                          isadmin = true
                        }


                        UsersaccountsRef.once("value",(eres1)=>{

                          if(eres1.val()==null && authe.user.email != "warebotcare@gmail.com"){

                            UsersaccountsRef.child("profile").set({
                              "Name": authe.user.displayName,
                              "mail":authe.user.email,
                            }).then((e)=>{
                              storeCookie("__tkn__", authe.user.uid)
                              console.log(e);
                              
      
                              storeCookie("profile", JSON.stringify({
                                "uid": authe.user.uid,
                                "name": authe.user.displayName,
                                "profile":authe.user.photoURL,
                                "mail":authe.user.email,
                                "isadmin":isadmin
                              }));
      
                              if(isadmin){
                                window.location.href = "/admin"
                              }else{
                                window.location.href = "/"
      
                              }
                            }).catch((err)=>{
                              console.log(err);
                              
                              alert("unable to create a account retry")
                            })
                            


                          }else{
                            storeCookie("__tkn__", authe.user.uid)
                            console.log(authe);
                            
    
                            storeCookie("profile", JSON.stringify({
                              "uid": authe.user.uid,
                              "name": authe.user.displayName,
                              "profile":authe.user.photoURL,
                              "mail":authe.user.email,
                              "isadmin":isadmin
                            }));
    
                            if(isadmin){
                              window.location.href = "/admin"
                            }else{
                              window.location.href = "/"
    
                            }
                          }



                        });





                        
                       

                      })

                       
                      }).catch((err) => console.log(err));
                     

                    }}
                    label={google.btn.text}
                    disabled={google.btn.disabled}
                    type="dark"
                  />

                </Stack>
              </Card>
            </Stack>
            

            <Typography variant="h5"  style={{marginTop:"180px"}}>
              Powered by
            </Typography>

            <img src={icon2} alt="logo" height={50}width={320}/>


            <Typography variant="body2">
              By continuing with google, you are accepting the following:
            </Typography>
            <Stack direction="row" spacing={1} fontFamily={"inherit"}>
              <Link
                href=""
                underline="none"
                fontFamily={"Arial"}
              >
                Terms of service
              </Link>
              <Link
                href=""
                underline="none"
                id="tou"
                fontFamily={"Arial"}
              >
                Terms of use
              </Link>
              <Link
                href=""
                underline="none"
                id="privacy"
                fontFamily={"Arial"}
              >
                Privacy policy
              </Link>
            </Stack>
          </Stack>
        </>
      );
    } else if (view === "loading") {
      return <LinearProgress />;
    } else {
      return <div>Something went Wrong!</div>;
    }
  }
}


export default Login;

