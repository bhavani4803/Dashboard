import { Link } from "@mui/material";
import React, { Component } from "react";
import { Outlet } from "react-router-dom";
import { AuthConsumer, AuthProvider } from "../context";
import firebase from "firebase";
import { render } from "react-dom";
import { getCookie } from "../../controller/cookie.controller";
type props = {
  navigate: any;
};

class AuthComponent extends Component {
  state: Readonly<{
    view: "ok" | "unauthorized" | "loading" | "poll_error";
    user: any;
  }>;
  props: props;
  constructor(props: props) {
    super(props);
    this.props = props;
    this.state = {
      view: "loading",
      user: {},
    };
  }
  firebaseConfig = {
    apiKey: "AIzaSyALIxWc98nMBPC5opE4cG_o-4zF3epKwDQ",
    authDomain: "warebot-6957c.firebaseapp.com",
    databaseURL: "https://warebot-6957c-default-rtdb.firebaseio.com",
    projectId: "warebot-6957c",
    storageBucket: "warebot-6957c.appspot.com",
    messagingSenderId: "772347476312",
    appId: "1:772347476312:web:dd68b3449643fc8c16cd2d",
    measurementId: "G-HNR0VKT0PD",
  };

  componentDidMount() {
    var token_: any = "";
    var profile: any = "";
    try {
      token_ = getCookie("__tkn__");
    } catch {
      window.location.replace("/login");
      return;
    }
    var objUser:any = {};
    try {
      profile = getCookie("profile");

      objUser = JSON.parse(profile);
    } catch {
      window.location.replace("/login");
      return;
    }

    if (token_) {
      
      console.log(objUser);

      var { uid } = objUser;
      console.log("authparams", uid);

      firebase.apps.length <= 0
        ? firebase.initializeApp(this.firebaseConfig)
        : firebase.app();

      const database = firebase.database();
      const accountsRef = database.ref("admins").child(uid); // Replace 'accounts' with the actual path to your data in the database.
      accountsRef
        .once("value", (eres:any) => {
          console.log(eres.val());
          var isadmin = false;
          var user1 ={ accesstype: "admin",email:"",uid:uid  };
          if (eres.val() == null) {
            isadmin = false;
            user1 = { accesstype: "dealer",email:"",uid:uid };
          } else {
            isadmin = true;
            user1 = { accesstype: "admin",email:eres.val(),uid:uid  };
          }

          this.setState({ view: "ok", user:user1 });
        })
        .catch(() => {
          this.setState({ view: "poll_error" });
        });
    } else {
      window.location.href = "/login";
    }
  }

  render() {
    var { view, user } = this.state;
    if (view === "ok") {
      return (
        <AuthProvider value={{ ...this.props, user }}>
          <Outlet></Outlet>
        </AuthProvider>
      );
    } else if (view === "loading") {
      return <>Loading...</>;
    } else if (view === "unauthorized") {
      return <>You are not allowed to use this website.</>;
    } else {
      return <>Something went wrong</>;
    }
  }
}

export default class Auth extends Component {
  render() {
    return (
      <AuthConsumer>
        {(props: any) => {
          console.log(props);
          return <AuthComponent {...this.props} {...props} />;
        }}
      </AuthConsumer>
    );
  }
}
