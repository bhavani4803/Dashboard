export class Url {
    private url: URL;
    urlParams: URLSearchParams;
    constructor(url: string) {
      this.url = new URL(url);
      this.urlParams = this.url.searchParams;
      this.addTempRedirect();
    }
    private addTempRedirect() {
      var redirectTo = this.urlParams.get("bs_continue") || null;
      if (redirectTo) {
        sessionStorage.setItem("REDIRECT", String(redirectTo));
        window.history.replaceState({}, document.title, "/");
      }
    }
    get isGoogleRedirect() {
      return (
        this.urlParams.has("scope") &&
        this.urlParams.has("prompt") &&
        this.urlParams.has("code")
      );
    }
    get isGithubRedirect() {
      return (
        this.urlParams.has("code") &&
        (this.urlParams.has("state") || this.urlParams.has("setup_action")) &&
        (this.urlParams.get("state") === "GithubBlockySite" ||
          this.urlParams.get("setup_action") === "install")
      );
    }
    get code() {
      return this.urlParams.get("code");
    }
    get CreatorWantDeployAuth() {
      var type = this.urlParams.has("deploy") && this.urlParams.get("deploy");
      return type;
    }
  }