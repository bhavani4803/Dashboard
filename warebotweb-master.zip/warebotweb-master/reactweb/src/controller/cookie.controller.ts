import { AES } from "crypto-js";
import Cookies from "js-cookie";
import CryptoJS from "crypto-js"

export function storeCookie(key: string, data: string) {
  var encrypted_token = AES.encrypt(
    data,
    "iugshdyb"
  ).toString();

  Cookies.set(key, encrypted_token, {
    domain:window.location.hostname,
    expires: 7,
  });
}

export function getCookie(key: string) {
  const encryptedToken = Cookies.get(key);

  if (encryptedToken) {
    const decryptedBytes = AES.decrypt(encryptedToken, "iugshdyb");
    const decryptedData = decryptedBytes.toString(CryptoJS.enc.Utf8);

    return decryptedData;
  } else {
    return null; // Cookie doesn't exist
  }
}
export function redirect() {
  var redirect =
    sessionStorage.getItem("REDIRECT") || "https://accounts.blockysite.com";
  sessionStorage.removeItem("REDIRECT");
  console.log("redirecting to " + redirect);
  window.location.href = redirect;
}

export function encryptToken(data: string) {
  return AES.encrypt(
    data,
    "iugshdyb"
  ).toString();
}