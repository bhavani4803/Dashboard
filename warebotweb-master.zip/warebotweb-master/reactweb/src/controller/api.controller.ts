export var ApiHost =
  process.env.NODE_ENV === "production"
    ? "https://api.blockysite.com"
    : window.location.protocol + "//" + window.location.hostname + ":3000";