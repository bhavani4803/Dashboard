import GoogleConfig from "../configs/google.json";
import axios from "axios";
import { ApiHost } from "./api.controller";
import { storeCookie } from "./cookie.controller";
export function continue_with_google() {
  var { client_id, scopes } = GoogleConfig;
  var redirect_uri = window.location.href;

  var finalUrl =
    "https://accounts.google.com/signin/oauth?client_id=" +
    client_id +
    "&response_type=code&access_type=offline&scope=" +
    scopes.join(" ") +
    "&redirect_uri=" +
    redirect_uri +
    "&prompt=consent";
  window.location.href = finalUrl;
}

export function getToken(code: string) {
  return new Promise<any>((resolve, reject) => {
    var redirect_url = window.location.protocol + "//" + window.location.host;
    console.log(redirect_url);
   
    if(!code){
      return
    }
axios
.post('https://oauth2.googleapis.com/token', {
  code: code,
  client_id: "772347476312-oshmtacgdfd6iba46k1cdnf47pdq8pnh.apps.googleusercontent.com",
  client_secret: "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",
  redirect_uri: window.location.origin+"/login",
  grant_type: 'authorization_code',
})
.then((response) => {
  const accessToken = response.data.access_token;
console.log(response);

  // Step 2: Use the access token to fetch the user's profile
  axios
    .get(`https://www.googleapis.com/oauth2/v1/userinfo?access_token=${accessToken}`, {
     
    })
    .then((profileResponse) => {
      const userProfile = profileResponse.data;
      console.log('User Profile:', userProfile);
      storeCookie("profile",JSON.stringify(profileResponse.data));
      resolve(response.data);

    })
    .catch((profileError) => {
      console.error('Error fetching user profile:', profileError);
      reject(profileError)
    });
})
.catch((error) => {
  console.error('Error exchanging auth code for access token:', error);
  reject(error)

});


  });
}
export function authenticateUser(code: string) {
  return new Promise<any>((resolve, reject) => {
    if(!code){
      return
    }
    getToken(code)
      .then((data) => {
        console.log(data);
        
        var cred = {
          google_access_token: data.access_token,
          google_refresh_token: data.refresh_token,
          google_expiry_at: data.expiry_at
        };
        resolve(JSON.stringify(cred));
      })
      .catch(reject);
  });
}