import React, { Component } from "react";
import { Autocomplete, Avatar, Button, FormControl, InputLabel, MenuItem, Select, Stack, TextField } from "@mui/material";
import { AuthConsumer } from "../authentication/context";
import firebase from "firebase";
import { Link } from "react-router-dom";
import TableGrid from "../AdminNavbar/components/TableGrid";
type props = {
  user: { email: string; uid: string };
  params: { useruid: string; base64: string };
  navigate: any;
};
class UserComponent extends Component {
  props: props;
  state: Readonly<{
    user: any;
    view: "loading" | "ok" | "error";
    updateBtn: boolean;
    loading: any;
    packstatus:any;
  }>;
  constructor(props: props) {
    super(props);
    this.props = props;
    this.state = {
      updateBtn: false,
      view: "loading",
      user: {
        access_token: "",
        uid: "",
        name: "",
        email: "",
        phone: "",
        address: "",
        image: "",
        id: "",
        devices: [],
      },
      loading: true,
      packstatus:10
    };
  }
  firebaseConfig = {
    apiKey: "AIzaSyALIxWc98nMBPC5opE4cG_o-4zF3epKwDQ",
    authDomain: "warebot-6957c.firebaseapp.com",
    databaseURL: "https://warebot-6957c-default-rtdb.firebaseio.com",
    projectId: "warebot-6957c",
    storageBucket: "warebot-6957c.appspot.com",
    messagingSenderId: "772347476312",
    appId: "1:772347476312:web:dd68b3449643fc8c16cd2d",
    measurementId: "G-HNR0VKT0PD",
  };

  componentDidMount(): void {
    var {
      params: { useruid },
    } = this.props;

    firebase.apps.length <= 0
      ? firebase.initializeApp(this.firebaseConfig)
      : firebase.app();

    const database = firebase.database();
    const accountsRef = database.ref("Users").child(useruid); // Replace 'accounts' with the actual path to your data in the database.
  
    database.ref("Device").once("value", (eres1:any) => {
      eres1 = eres1.val();
      console.log(eres1);
      
      
      accountsRef.once("value", (eres) => {
        console.log(eres.val());
        var data: any = eres.val();
  
        if (data == null) {
          this.setState({ view: "data not found" });
        } else if (data.length <= 0) {
          this.setState({ view: "no data found" });
        } else {
          var usersdata: any = [];
  
          Object.keys(data.devices).map((ee: any, id: number) => {
  
                  
              if (data == null) {
                this.setState({ view: "data not found" });
              } else if (data.length <= 0) {
                this.setState({ view: "no data found" });
              } else {
                var usersdata: any = [];
        
                Object.keys(data.devices).map((ee: any, id: number) => {
                 
                  usersdata.push({
                    "id":id,
                    "name":data.devices[ee],
                    "uid":ee,
                    "pack":eres1[ee] && eres1[ee]["setpoints"].pack?eres1[ee]["setpoints"].pack:10
                  });
                });
                data["profile"]["uid"] = useruid;
        
                console.log(usersdata,data);
        
                this.setState({
                  user: { ...data.profile, usersdata },
                  view: "ok",
                  loading: false,
                  
                });
              }
        
           
            
          });
          
        }
      });
    }).catch((err)=>{

    })
  
  

  

    // getDevices(uid)
    //   .then(({ data }) => {
    //     if (data.status === 200) {
    //       var devices = data.devices.filter((device: any) => device !== "");
    //       console.log(devices);
    //     } else {
    //       console.log(data);
    //       this.setState({ view: "error" });
    //     }
    //   })
    //   .catch((err) => {
    //     console.log(err);
    //     this.setState({ view: "error" });
    //   });
  }

  packstatushandleChange=(macuid:any,val:any)=>{

    const{user}=this.state;
    
    const database = firebase.database();
    const accountsRef = database.ref("Device").child(macuid); 


    accountsRef.child("setpoints/pack").set(val).then((e)=>{

      alert("pack status updated");

      user.usersdata.find((ep:any)=>{
        if(ep.uid==macuid){
          ep.pack = val
        }
      })
      this.setState({user})
    }).catch((err)=>{
      alert("pack status update error");

    })


    
  }
 

  render() {
    var { view, user, updateBtn, loading ,packstatus} = this.state;

    if (view === "ok") {
      return (
        <Stack alignItems={"center"} sx={{ mt: "1rem" }} gap={1}>
          {" "}
          <Avatar
            alt={user.name}
            src={user.image}
            variant="rounded"
            sx={{ width: "100px", height: "100px" }}
            imgProps={{
              referrerPolicy: "no-referrer",
            }}
          />
          <div>
            <h1>Name: {user.Name}</h1>
            <h4>Email: {user.mail}</h4>
            <h4>Phone: {user.phone}</h4>
          </div>

        
        
          <Stack direction={"row"} gap={1}>
            <Stack spacing={3} sx={{ width: 500 }}>
              <Autocomplete
                size="small"
                multiple
                freeSolo
                options={[]}
                value={Object.keys(user.usersdata).map((e)=>user.usersdata[e].uid)}
                renderInput={(params) => (
                  <TextField {...params} label="Devices" />
                )}
                onChange={(e, value) => {
                  var user = this.state.user;
                  user.devices = value;
                  this.setState({ user });
                }}
              />
            </Stack>
            <Button
              variant="outlined"
              disabled={updateBtn}
              onClick={() => {
                this.setState({ updateBtn: true });
                // updateDevices(user.devices, user.uid)
                //   .then(({ data }) => {
                //     if (data.status === 200) {
                //       this.setState({ updateBtn: false });
                //       alert("Updated");
                //     } else {
                //       console.log(data);
                //       this.setState({ updateBtn: false, view: "error" });
                //     }
                //   })
                //   .catch((err) => {
                //     console.log(err);
                //     this.setState({ updateBtn: false, view: "error" });
                //   });
              }}
            >
              {updateBtn ? "Updating..." : "Update"}
            </Button>
          </Stack>

         

          <div style={{ marginTop: "10px" ,minWidth:"700px"}}>
            <TableGrid
              rows={user.usersdata}
              columns={[
                {
                  field: "name",
                  headerName: "Device Name",
                  renderCell: (params: any) => {
                    return (
                      <Link to={"/" + params.row.uid+"#"+this.props.params.useruid}>
                        {params.row.name}
                      </Link>
                    );
                  },
                  flex: 1,
                },
                {
                  field: "uid",
                  headerName: "Device Uid",
                  flex: 1,
                },
                {
                  field: "pack",
                  headerName: "Pack",
                  flex: 1,
                  renderCell: (params: any) => {
                    return (
                    

<div>
<FormControl sx={{minWidth:"200px"}}>
  <InputLabel id="demo-simple-select-label">Pack Status</InputLabel>
  <Select
    labelId="demo-simple-select-label"
    id="demo-simple-select"
    value={params.row.pack}
    label="Pack status"
    onChange={(e:any)=>{
      console.log(e.target.value);
      
      this.packstatushandleChange(params.row.uid,e.target.value)
    }}
  >
    <MenuItem value={10}>Expired</MenuItem>
    <MenuItem value={20}>Instant</MenuItem>
    <MenuItem value={30}>Trial</MenuItem>
    <MenuItem value={40}>1 month</MenuItem>
    <MenuItem value={50}>3 month</MenuItem>
    <MenuItem value={60}>6 month</MenuItem>
    <MenuItem value={70}>1 year</MenuItem>
  </Select>
</FormControl>
</div>

                    );
                  },
                }

              ]}
              isLoading={loading}
            />
          </div>
        </Stack>
      );
    }
    if (view === "loading") return <div>Loading...</div>;
    if (view === "error") return <div>Error</div>;
  }
}
export default class User extends Component {
  render() {
    return (
      <AuthConsumer>
        {(props: any) => {
          console.log(props);
          return <UserComponent {...this.props} {...props} />;
        }}
      </AuthConsumer>
    );
  }
}
