import React, { Component } from "react";

import { Link } from "react-router-dom";
import { Avatar } from "@mui/material";
import TableGrid from "../AdminNavbar/components/TableGrid";
import { AuthConsumer } from "../authentication/context";
import firebase from "firebase";
type props = { user: { email: string; accesstype: string; uid: string } };
class UsersComponent extends Component {
  props: props;
  state: Readonly<{
    view: "loading" | "ok" | "error";
    loading: boolean;
    users: any;
  }>;
  constructor(props: props) {
    super(props);
    this.props = props;
    this.state = {
      view: "ok",
      loading: true,
      users: [],
    };
  }
  firebaseConfig = {
    apiKey: "AIzaSyALIxWc98nMBPC5opE4cG_o-4zF3epKwDQ",
    authDomain: "warebot-6957c.firebaseapp.com",
    databaseURL: "https://warebot-6957c-default-rtdb.firebaseio.com",
    projectId: "warebot-6957c",
    storageBucket: "warebot-6957c.appspot.com",
    messagingSenderId: "772347476312",
    appId: "1:772347476312:web:dd68b3449643fc8c16cd2d",
    measurementId: "G-HNR0VKT0PD",
  };

  componentDidMount(): void {
    var {
      user: { email, accesstype, uid },
    } = this.props;

    console.log(email, accesstype, uid);
    firebase.apps.length <= 0
      ? firebase.initializeApp(this.firebaseConfig)
      : firebase.app();

    const database = firebase.database();
    const accountsRef = database.ref("Users"); // Replace 'accounts' with the actual path to your data in the database.
    accountsRef.once("value", (eres) => {
      console.log(eres.val());
      var data = eres.val();

      if (data == null) {
        this.setState({ view: "data not found" });
      } else if (data.length <= 0) {
        this.setState({ view: "no data found" });
      } else {
        var usersdata: any = [];

       
          Object.keys(data)
            .filter((e: any) => data[e].profile)
            .map((ee: any, id: number) => {
              data[ee].profile["uid"] = ee;
              data[ee].profile["id"] = id;
              if (
                !data[ee].profile["image"] ||
                data[ee].profile["image"].length <= 0
              ) {
                data[ee].profile["image"] =
                  "https://img.icons8.com/fluency/48/person-male.png";
              }
              data[ee].profile["devicescount"] = 0;

              if (data[ee]["devices"]) {
                data[ee].profile["devicescount"] = Object.keys(data[ee]["devices"]).length;
                usersdata.push(data[ee].profile);
              }

            });

          console.log(usersdata);

          this.setState({ users: usersdata, loading: false });
        
      }
    });
  }
  render() {
    var { view, loading, users } = this.state;
    if (view === "ok") {
      return (
        <TableGrid
          rows={users}
          columns={[
            {
              field: "image",
              headerName: "Image",
              renderCell: (params: any) => {
                return (
                  <Avatar
                    alt={params.row.Name}
                    src={params.row.image}
                    variant="rounded"
                    imgProps={{
                      referrerPolicy: "no-referrer",
                    }}
                  />
                );
              },
              flex: 1,
            },
            {
              field: "Name",
              headerName: "Name",
              renderCell: (params: any) => {
                const text = JSON.stringify(params.row);
                return (
                  <Link to={"/users/" + params.row.uid}>{params.row.Name}</Link>
                );
              },
              flex: 1,
            },
            {
              field: "mail",
              headerName: "Email",
              flex: 1,
            },
            {
              field: "phone",
              headerName: "Phone",
              flex: 1,
            },
            {
              field: "devicescount",
              headerName: "Devices",
              flex: 1,
            }
          ]}
          isLoading={loading}
          
        />
      );
    } else {
      return <div>Something went wrong</div>;
    }
  }
}
export default class AdminUsers extends Component {
  render() {
    return (
      <AuthConsumer>
        {(props: any) => {
          console.log(props);
          return <UsersComponent {...this.props} {...props} />;
        }}
      </AuthConsumer>
    );
  }
}
