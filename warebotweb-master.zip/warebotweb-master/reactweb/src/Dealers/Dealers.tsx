import React, { Component } from "react";
import Navbar from "../navbar/navbar";
import AdminNavbar from "../AdminNavbar/AdminNavbar";
import { Avatar } from "@mui/material";
import { Link } from "react-router-dom";
import TableGrid from "../AdminNavbar/components/TableGrid";
import { AuthConsumer } from "../authentication/context";
import firebase from "firebase";

type props = { user: { email: string; accesstype: string,uid:String } };

const pages = ["Home"];
const settings = ["Logout"];

const firebaseConfig = {
    apiKey: "AIzaSyALIxWc98nMBPC5opE4cG_o-4zF3epKwDQ",
    authDomain: "warebot-6957c.firebaseapp.com",
    databaseURL: "https://warebot-6957c-default-rtdb.firebaseio.com",
    projectId: "warebot-6957c",
    storageBucket: "warebot-6957c.appspot.com",
    messagingSenderId: "772347476312",
    appId: "1:772347476312:web:dd68b3449643fc8c16cd2d",
    measurementId: "G-HNR0VKT0PD",
  };

class DealersComponents extends Component {
  props: props;
  state: Readonly<{
    view: "loading" | "ok" | "error";
    loading: boolean;
    users: {}[];
  }>;
  constructor(props: props) {
    super(props);
    this.props = props;
    this.state = {
      view: "ok",
      loading: true,
      users: [],
    };
  }

  componentDidMount = () => {
    var {
        user: {uid,email ,accesstype},
      } = this.props;

      console.log(uid,email,accesstype);

      firebase.apps.length <= 0
      ? firebase.initializeApp(firebaseConfig)
      : firebase.app();

    const database = firebase.database();
    const accountsRef = database.ref("Device"); // Replace 'accounts' with the actual path to your data in the database.
    accountsRef.once("value", (eres) => {
      console.log(eres.val());
      var data = eres.val();

      if (data == null) {
        this.setState({ view: "data not found" });
      } else if (data.length <= 0) {
        this.setState({ view: "no data found" });
      } else {
        var usersdata: any = [];

        console.log(data);
        

        Object.keys(data)
          .filter((e: any) => data[e].viewers)
          .map((ee: any,id:number) => {
         
            data[ee].viewers["uid"] = ee;
            data[ee].viewers["id"] = id;
            data[ee].viewers["name"] = data[ee];
          

            usersdata.push(data[ee].profile);
          });

        console.log(usersdata);

        // this.setState({ users:usersdata, loading: false });
      }
    });



      

  };

  render() {
    var { view, loading, users } = this.state;
    var { user } = this.props;

    if (view === "ok") {
      return (
        <div>
          <AdminNavbar
            user={{
              email: user.email,
              accesstype: user.accesstype,
              pages: pages,
              settings: settings,
            }}
          ></AdminNavbar>

          <TableGrid
            rows={users}
            columns={[
              {
                field: "image",
                headerName: "Image",
                renderCell: (params: any) => {
                  return (
                    <Avatar
                      alt={params.row.name}
                      src={params.row.image}
                      variant="rounded"
                      imgProps={{
                        referrerPolicy: "no-referrer",
                      }}
                    />
                  );
                },
                flex: 1,
              },
              {
                field: "name",
                headerName: "Name",
                renderCell: (params: any) => {
                  
                  return (
                    <Link to={"/viewer/" + params.row.uid}>
                      {params.row.name}
                    </Link>
                  );
                },
                flex: 1,
              },
              {
                field: "mail",
                headerName: "Email",
                flex: 1,
              },
              {
                field: "status",
                headerName: "status",
                flex: 1,
              }
            ]}
            isLoading={loading}
          />
        </div>
      );
    } else {
      return <div>Something went wrong</div>;
    }
  }
}

export default class Dealers extends Component {
  render() {
    return (
      <AuthConsumer>
        {(props: any) => {
          console.log(props);
          return <DealersComponents {...this.props} {...props} />;
        }}
      </AuthConsumer>
    );
  }
}


